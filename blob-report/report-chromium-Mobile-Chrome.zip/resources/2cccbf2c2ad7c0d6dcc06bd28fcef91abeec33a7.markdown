# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: e2e/shift-notes.spec.ts >> Shift Notes E2E >> Edit fields and verify dirty tracking
- Location: tests/e2e/shift-notes.spec.ts:56:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('heading', { name: 'Shift Notes', exact: true, level: 1 })
Expected: visible
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 15000ms
  - waiting for getByRole('heading', { name: 'Shift Notes', exact: true, level: 1 })

```

```yaml
- region "Notifications alt+T"
- img "InsideCare"
- heading "Sign In" [level=1]
- paragraph: Welcome back! Log in with your credentials.
- alert: Development Environment - For testing only
- text: Email
- textbox "Email":
  - /placeholder: Your email
- text: Password
- textbox "Password":
  - /placeholder: Your password
- button
- checkbox "Remember me" [checked]
- text: Remember me
- link "Forgot Password?":
  - /url: /auth/reset-password
- button "Sign In"
- paragraph: Testing & Development
- button "Admin"
- button "Support Worker"
- button "Supervisor"
- button "House Manager"
- button "Director"
- button "Finance Manager"
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | 
  3  | test.describe('Shift Notes E2E', () => {
  4  |   // Use admin session
  5  |   test.use({ storageState: 'playwright/.auth/admin.json' });
  6  | 
  7  |   test.beforeEach(async ({ page }) => {
  8  |     await page.goto('/participants/shift-notes');
  9  |     // Ensure loading is finished or basic elements are visible
> 10 |     await expect(page.getByRole('heading', { name: 'Shift Notes', exact: true, level: 1 })).toBeVisible({ timeout: 15000 });
     |                                                                                             ^ Error: expect(locator).toBeVisible() failed
  11 |     await page.waitForLoadState('networkidle');
  12 |   });
  13 | 
  14 |   test('Navigate to detailed shift note form and verify sections', async ({ page }) => {
  15 |     // Click on "Add Shift Note"
  16 |     const addBtn = page.getByRole('button', { name: /Add Shift Note/i });
  17 |     await expect(addBtn).toBeVisible({ timeout: 30000 });
  18 |     await addBtn.click({ force: true });
  19 | 
  20 |     // Verify redirection to the detail page for a new note
  21 |     await expect(page).toHaveURL(/\/shift-notes\/detail\/new/, { timeout: 30000 });
  22 | 
  23 |     // Verify primary sections are present via Sidebar links
  24 |     await expect(page.getByText('Overview', { exact: true }).first()).toBeVisible({ timeout: 30000 });
  25 |     await expect(page.getByText('Supports', { exact: true }).first()).toBeVisible();
  26 |     await expect(page.getByText('Health & Medication', { exact: true }).first()).toBeVisible();
  27 |     await expect(page.getByText('Trackers', { exact: true }).first()).toBeVisible();
  28 |     await expect(page.getByText('Summary', { exact: true }).first()).toBeVisible();
  29 | 
  30 |     // Verify content sections
  31 |     await expect(page.locator('#shift_note_overview')).toBeVisible();
  32 |     await expect(page.locator('#shift_note_supports')).toBeVisible();
  33 |   });
  34 | 
  35 |   test('Toggle clinical trackers and verify visibility', async ({ page }) => {
  36 |     await page.goto('/shift-notes/detail/new');
  37 |     await expect(page.locator('#shift_note_trackers')).toBeVisible({ timeout: 30000 });
  38 | 
  39 |     // Initially, Bowel Tracking card should NOT be visible
  40 |     await expect(page.locator('#tracker_bowel')).not.toBeVisible();
  41 | 
  42 |     // Click the Bowel Tracking toggle (click the card/div wrapper)
  43 |     await expect(page.locator('div').filter({ hasText: /^Bowel Tracking$/ }).first()).toBeVisible();
  44 |     
  45 |     // Sometimes clicking the div is tricky, try clicking the label or the checkbox if needed, 
  46 |     // but here we'll try to click it more precisely or use the checkbox id
  47 |     await page.locator('label[for="bowel_toggle"]').or(page.locator('div').filter({ hasText: /^Bowel Tracking$/ }).first()).first().click({ force: true });
  48 | 
  49 |     // Verify the Bowel Tracking card appears
  50 |     await expect(page.locator('#tracker_bowel')).toBeVisible({ timeout: 15000 });
  51 |     
  52 |     // Verify Bristol Scale is visible inside the card
  53 |     await expect(page.getByText('Bristol Scale Type *')).toBeVisible();
  54 |   });
  55 | 
  56 |   test('Edit fields and verify dirty tracking', async ({ page }) => {
  57 |     await page.goto('/shift-notes/detail/new');
  58 |     
  59 |     // Modify a field (e.g., Overall Presentation)
  60 |     const presentationInput = page.locator('textarea#overall_presentation');
  61 |     await expect(presentationInput).toBeVisible({ timeout: 15000 });
  62 |     
  63 |     await presentationInput.fill('Participant was engaged and happy.');
  64 | 
  65 |     // Verify "Save Changes" or "Create" button becomes enabled
  66 |     const saveButton = page.getByRole('button', { name: /Create/i });
  67 |     await expect(saveButton).toBeEnabled();
  68 |   });
  69 | });
  70 | 
```