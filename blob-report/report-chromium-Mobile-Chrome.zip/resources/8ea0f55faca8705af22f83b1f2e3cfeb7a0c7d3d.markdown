# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: e2e/participant-marathon.spec.ts >> Participant Detail Marathon CRUD >> Create and Fully Populate Participant Record
- Location: tests/e2e/participant-marathon.spec.ts:10:3

# Error details

```
TimeoutError: page.waitForEvent: Timeout 15000ms exceeded while waiting for event "filechooser"
=========================== logs ===========================
waiting for event "filechooser"
============================================================
```

# Page snapshot

```yaml
- generic:
  - generic:
    - region "Notifications alt+T"
    - generic:
      - generic:
        - link:
          - /url: /
          - generic:
            - img
        - button:
          - img
      - generic:
        - generic:
          - generic:
            - menu:
              - generic:
                - heading [level=3]:
                  - button:
                    - link:
                      - /url: /my-dashboard
                      - img
                      - generic: My Dashboard
              - text: Staff Portal
              - generic:
                - heading [level=3]:
                  - button:
                    - link:
                      - /url: /my-checklists
                      - img
                      - generic: House Checklists
              - generic:
                - heading [level=3]:
                  - button:
                    - link:
                      - /url: /my-roster
                      - img
                      - generic: My Roster
              - generic:
                - heading [level=3]:
                  - button:
                    - link:
                      - /url: /my-leave
                      - img
                      - generic: My Leave
              - generic:
                - heading [level=3]:
                  - button:
                    - link:
                      - /url: /my-timesheets
                      - img
                      - generic: My Timesheets
              - text: People & Houses
              - generic:
                - heading [level=3]:
                  - button:
                    - link:
                      - /url: /staff
                      - img
                      - generic: Staff
              - generic:
                - heading [level=3]:
                  - button:
                    - link:
                      - /url: /houses
                      - img
                      - generic: Houses
              - generic:
                - heading [level=3]:
                  - button [expanded]:
                    - img
                    - generic: Participants
                    - img
                - region:
                  - menu:
                    - group:
                      - generic:
                        - heading [level=3]:
                          - button:
                            - link:
                              - /url: /participants/profiles
                              - text: Participant Profiles
                      - generic:
                        - heading [level=3]:
                          - button:
                            - link:
                              - /url: /participants/medication-register
                              - text: Medication Register
                      - generic:
                        - heading [level=3]:
                          - button:
                            - link:
                              - /url: /participants/shift-notes
                              - text: Shift Notes
              - text: Roster & Staff Scheduling
              - generic:
                - heading [level=3]:
                  - button:
                    - link:
                      - /url: /roster-board
                      - img
                      - generic: Roster Board
              - generic:
                - heading [level=3]:
                  - button:
                    - link:
                      - /url: /shift-setup
                      - img
                      - generic: Shift Setup
              - generic:
                - heading [level=3]:
                  - button:
                    - link:
                      - /url: /timesheet-approvals
                      - img
                      - generic: Timesheet Approvals
              - generic:
                - heading [level=3]:
                  - button:
                    - link:
                      - /url: /leave-approvals
                      - img
                      - generic: Leave Approvals
              - text: Administration
              - generic:
                - heading [level=3]:
                  - button:
                    - link:
                      - /url: /access-control
                      - img
                      - generic: Access Control
              - generic:
                - heading [level=3]:
                  - button:
                    - link:
                      - /url: /checklist-templates
                      - img
                      - generic: Checklist Templates
              - generic:
                - heading [level=3]:
                  - button:
                    - link:
                      - /url: /reporting
                      - img
                      - generic: Reporting
              - generic:
                - heading [level=3]:
                  - button:
                    - link:
                      - /url: /activity-log
                      - img
                      - generic: Activity Log
    - generic:
      - banner:
        - generic:
          - generic:
            - button:
              - img
            - generic:
              - generic:
                - generic:
                  - img
      - main:
        - generic:
          - generic:
            - generic:
              - generic:
                - generic:
                  - button:
                    - img
                    - text: Back
                  - generic:
                    - heading [level=1]: Participant Details
                    - generic: View and manage participant information
              - generic:
                - button: Save Changes
        - generic:
          - generic:
            - generic:
              - generic:
                - generic:
                  - generic:
                    - generic: Personal Details
                    - generic: Goals
                    - generic: Behaviour & Support
                    - generic:
                      - generic: Support Needs
                      - generic:
                        - generic: Personal Care and Routine
                        - generic: Mobility
                        - generic: Meal Preparation
                        - generic: Household Tasks
                        - generic: Communication
                        - generic: Finances
                        - generic: Health and Wellbeing
                        - generic: Cultural and Religious
                        - generic: Other
                    - generic: Mealtime Management
                    - generic:
                      - generic: Medical Routine
                      - generic:
                        - generic: Pharmacy
                        - generic: General Practitioner
                        - generic: Psychiatrist
                    - generic: Medications
                    - generic: Emergency Management
                    - generic: Contacts
                    - generic: Documents
                    - generic: Shift Notes
                    - generic: Activity Log
            - generic:
              - generic:
                - generic:
                  - heading [level=3]: Personal Details
                - generic:
                  - generic:
                    - generic: Photo
                    - generic:
                      - generic:
                        - button:
                          - img
                        - generic:
                          - img
                          - generic:
                            - img
                  - generic:
                    - generic:
                      - generic: Full Name *
                      - generic:
                        - textbox: Full Lifecycle Participant 1780370108600
                  - generic:
                    - generic:
                      - generic: NDIS Number
                      - textbox: "987654321"
                  - generic:
                    - generic:
                      - generic: Date of Birth
                      - textbox: 2000-01-01
                  - generic:
                    - generic:
                      - generic: House Phone
                      - textbox
                  - generic:
                    - generic:
                      - generic: Personal Mobile
                      - textbox: "0411111111"
                  - generic:
                    - generic:
                      - generic: Email
                      - generic:
                        - textbox
                  - generic:
                    - generic:
                      - generic: Address
                      - textbox: 789 Participant Rd, Perth WA
                  - generic:
                    - generic: Support Level
                    - generic:
                      - combobox:
                        - generic: High
                        - img
                  - generic:
                    - generic:
                      - generic: Support Coordinator
                      - textbox: John Coordinator
                  - generic:
                    - generic: House
                    - generic:
                      - combobox:
                        - generic: Select house
                        - img
                  - generic:
                    - generic: Status
                    - generic:
                      - combobox:
                        - generic: Draft
                        - img
              - generic:
                - generic:
                  - heading [level=3]: Goals
                  - button:
                    - img
                    - text: Add Goal
                - generic:
                  - generic:
                    - table:
                      - rowgroup:
                        - row:
                          - columnheader: Goal Type
                          - columnheader: Description
                          - columnheader: Progress
                          - columnheader: Actions
                      - rowgroup:
                        - row:
                          - cell:
                            - generic:
                              - img
                              - generic: Identified
                          - cell: Independent living skills and social inclusion
                          - cell: Save goal first
                          - cell:
                            - generic:
                              - button:
                                - img
                              - button:
                                - img
                              - button: Remove
              - generic:
                - generic:
                  - heading [level=3]: Behaviour Support
                - generic:
                  - generic:
                    - generic:
                      - generic: Behaviour of Concern
                      - textbox:
                        - /placeholder: Describe behaviour of concern...
                        - text: Occasional social anxiety in large groups.
                  - generic:
                    - generic: PBSP Engaged
                    - checkbox
                  - generic:
                    - generic: BSP Available
                    - checkbox
                  - generic:
                    - generic: Restrictive Practices
                    - checkbox
                  - generic:
                    - generic: Specialist Name
                    - textbox:
                      - /placeholder: Enter specialist name...
                      - text: Dr. Behaviour
                  - generic:
                    - generic: Specialist Phone
                    - textbox:
                      - /placeholder: Specialist Phone number...
                  - generic:
                    - generic: Specialist Email
                    - textbox:
                      - /placeholder: Specialist Email address...
                  - generic:
                    - generic: Restrictive Practice Authorisation
                    - checkbox
                  - generic:
                    - generic:
                      - generic: Restrictive Practice Details
                      - textbox:
                        - /placeholder: Describe restrictive practice details...
              - generic:
                - generic:
                  - heading [level=3]: Support Needs
                - generic:
                  - generic:
                    - heading [level=3]: Personal Care and Routine
                    - generic:
                      - generic:
                        - generic:
                          - generic: Routine
                          - textbox:
                            - /placeholder: Describe the daily routine...
                            - text: Morning walks, afternoon reading.
                      - generic:
                        - generic:
                          - generic: Hygiene Support Required
                          - textbox:
                            - /placeholder: Describe hygiene support needs...
                  - generic:
                    - heading [level=3]: Mobility
                    - generic:
                      - generic:
                        - generic: Mobility Support Required
                        - textbox:
                          - /placeholder: Describe mobility support needs...
                  - generic:
                    - heading [level=3]: Meal Preparation and Kitchen Safety
                    - generic:
                      - generic:
                        - generic: Meal Preparation Support Needs
                        - textbox:
                          - /placeholder: Describe meal preparation and kitchen safety support needs...
                  - generic:
                    - heading [level=3]: Household Tasks
                    - generic:
                      - generic:
                        - generic: Household Support Needs
                        - textbox:
                          - /placeholder: Describe household tasks support needs...
                  - generic:
                    - heading [level=3]: Communication
                    - generic:
                      - generic:
                        - generic:
                          - generic: Preferred Communication Type
                          - combobox:
                            - generic: Verbal
                            - img
                      - generic:
                        - generic:
                          - generic: Communication Type Notes
                          - textbox:
                            - /placeholder: Describe communication type preferences...
                            - text: Prefers clear, direct instructions.
                      - generic:
                        - generic:
                          - generic: Communication & Language Needs
                          - textbox:
                            - /placeholder: Describe how to communicate (e.g., firm tone, constant validation, etc.)...
                  - generic:
                    - heading [level=3]: Finances
                    - generic:
                      - generic:
                        - generic: Finance Support Needs
                        - textbox:
                          - /placeholder: Describe financial management support needs...
                          - text: Needs assistance with budget management.
                  - generic:
                    - heading [level=3]: Health and Wellbeing
                    - generic:
                      - generic:
                        - generic: Health & Wellbeing Support Needs
                        - textbox:
                          - /placeholder: Describe health and wellbeing support needs...
                  - generic:
                    - heading [level=3]: Cultural and Religious
                    - generic:
                      - generic:
                        - generic: Cultural and Religious Support Needs
                        - textbox:
                          - /placeholder: Describe cultural and religious support needs...
                  - generic:
                    - heading [level=3]: Other
                    - generic:
                      - generic:
                        - generic: Any Other Support Needs
                        - textbox:
                          - /placeholder: Describe any other support needs...
              - generic:
                - generic:
                  - heading [level=3]: Mealtime Management Plan
                - generic:
                  - generic:
                    - generic: Is there a MTMP?
                    - checkbox
                  - generic:
                    - generic: If Yes, provide details
                    - generic:
                      - textbox [disabled]:
                        - /placeholder: Describe the Mealtime Management Plan...
              - generic:
                - generic:
                  - heading [level=3]: Medical Routine
                - generic:
                  - generic:
                    - heading [level=3]: Pharmacy
                    - generic:
                      - generic:
                        - generic:
                          - generic: Pharmacy Name
                          - textbox:
                            - /placeholder: Enter pharmacy name...
                            - text: Central Pharmacy
                      - generic:
                        - generic:
                          - generic: Pharmacy Contact
                          - textbox:
                            - /placeholder: Enter pharmacy contact...
                      - generic:
                        - generic:
                          - generic: Pharmacy Location
                          - textbox:
                            - /placeholder: Enter pharmacy location...
                  - generic:
                    - heading [level=3]: General Practitioner
                    - generic:
                      - generic:
                        - generic:
                          - generic: GP Name
                          - textbox:
                            - /placeholder: Enter GP name...
                            - text: Dr. Smith
                      - generic:
                        - generic:
                          - generic: GP Contact
                          - textbox:
                            - /placeholder: Enter GP contact...
                      - generic:
                        - generic:
                          - generic: GP Location
                          - textbox:
                            - /placeholder: Enter GP location...
                  - generic:
                    - heading [level=3]: Psychiatrist
                    - generic:
                      - generic:
                        - generic:
                          - generic: Psychiatrist Name
                          - textbox:
                            - /placeholder: Enter psychiatrist name...
                            - text: Dr. Freud
                      - generic:
                        - generic:
                          - generic: Psychiatrist Contact
                          - textbox:
                            - /placeholder: Enter psychiatrist contact...
                      - generic:
                        - generic:
                          - generic: Psychiatrist Location
                          - textbox:
                            - /placeholder: Enter psychiatrist location...
                  - generic:
                    - generic:
                      - generic: Any Other
                      - textbox:
                        - /placeholder: Describe any other medical routine information...
                  - generic:
                    - generic:
                      - generic: General Process
                      - textbox:
                        - /placeholder: Describe the general medical routine process...
              - generic:
                - generic:
                  - heading [level=3]: Medications
                  - button:
                    - img
                    - text: Add Medication
                - generic:
                  - generic:
                    - table:
                      - rowgroup:
                        - row:
                          - columnheader: Medication
                          - columnheader: Dosage
                          - columnheader: Status
                          - columnheader: Actions
                      - rowgroup:
                        - row:
                          - cell:
                            - generic:
                              - img
                              - generic: Alprazolam
                              - generic: New
                          - cell: 10mg daily
                          - cell:
                            - generic: Active
                          - cell:
                            - generic:
                              - button: Remove
              - generic:
                - generic:
                  - heading [level=3]: Emergency Management Plan
                - generic:
                  - generic:
                    - generic:
                      - generic: Mental Health Plan
                      - textbox:
                        - /placeholder: Describe mental health management plan...
                  - generic:
                    - generic:
                      - generic: Medical Plan
                      - textbox:
                        - /placeholder: Describe medical emergency plan...
                  - generic:
                    - generic:
                      - generic: Natural Disaster / Relocation Plan
                      - textbox:
                        - /placeholder: Describe natural disaster and relocation procedures...
              - generic:
                - generic:
                  - heading [level=3]: Contacts
                  - button:
                    - img
                    - text: Add Contact
                - generic:
                  - generic:
                    - table:
                      - rowgroup:
                        - row:
                          - columnheader: Contact Name
                          - columnheader: Type
                          - columnheader: Phone
                          - columnheader: Email
                          - columnheader: Actions
                      - rowgroup:
                        - row:
                          - cell:
                            - generic:
                              - img
                              - generic: Jane Doe
                              - generic: New
                          - cell: Guadian
                          - cell: "0422222222"
                          - cell
                          - cell:
                            - generic:
                              - button: Remove
              - generic:
                - generic:
                  - heading [level=3]: Documents
                  - generic:
                    - generic:
                      - button:
                        - img
                      - button:
                        - img
                    - button:
                      - img
                      - text: Upload Document
                - generic:
                  - generic:
                    - generic:  
                    - paragraph: No documents uploaded yet
              - generic:
                - generic:
                  - heading [level=3]: Shift Notes
                - generic:
                  - generic: No shift notes available for this participant
              - generic:
                - generic:
                  - heading [level=3]: Activity Log
                - generic:
                  - generic: No activity recorded yet
      - generic:
        - contentinfo:
          - generic:
            - generic:
              - generic:
                - generic: 2026 © InsideCare. All rights reserved.
  - dialog "Upload Documents" [ref=e2]:
    - generic [ref=e3]:
      - heading "Upload Documents" [level=2] [ref=e4]
      - paragraph [ref=e5]: Drag and drop files here or click to browse. Multiple files supported.
    - generic [ref=e7] [cursor=pointer]:
      - button "Choose File" [active] [ref=e8]
      - generic [ref=e9]:
        - img [ref=e11]
        - generic [ref=e14]:
          - paragraph [ref=e15]: Drop files here or browse files
          - paragraph [ref=e16]: PDF, Word, Excel, Images, Zip (Max 10MB per file)
    - generic [ref=e17]:
      - button "Cancel" [ref=e18] [cursor=pointer]
      - button "Add to Queue" [disabled]
    - button "Close" [ref=e19] [cursor=pointer]:
      - img [ref=e20]
      - generic [ref=e23]: Close
```

# Test source

```ts
  1   | import { test, expect } from '@playwright/test';
  2   | 
  3   | /**
  4   |  * PARTICIPANT DETAIL MARATHON (GOLD STANDARD)
  5   |  * Covers every single field, every tab, and document uploads.
  6   |  */
  7   | test.describe('Participant Detail Marathon CRUD', () => {
  8   |   test.use({ storageState: 'playwright/.auth/admin.json' });
  9   | 
  10  |   test('Create and Fully Populate Participant Record', async ({ page }) => {
  11  |     page.on('console', msg => {
  12  |       if (msg.type() === 'error') console.log(`BROWSER ERROR: ${msg.text()}`);
  13  |     });
  14  | 
  15  |     const timestamp = Date.now();
  16  |     const participantName = `Full Lifecycle Participant ${timestamp}`;
  17  | 
  18  |     // 1. Initial Creation
  19  |     await page.goto('/participants/profiles');
  20  |     await page.getByRole('button', { name: /Add Participant/i }).click({ force: true });
  21  |     
  22  |     await expect(page).toHaveURL(/\/participants\/detail\//, { timeout: 30000 });
  23  |     await expect(page.getByRole('heading', { name: /Participant Details/i }).first()).toBeVisible({ timeout: 30000 });
  24  |     
  25  |     // 2. Profile Details (Core Fields)
  26  |     // Upload an avatar pic
  27  |     const avatarChooserPromise = page.waitForEvent('filechooser');
  28  |     await page.locator('#personal_details').locator('.relative.rounded-full').first().click(); 
  29  |     const avatarChooser = await avatarChooserPromise;
  30  |     await avatarChooser.setFiles({
  31  |       name: 'avatar.png',
  32  |       mimeType: 'image/png',
  33  |       buffer: Buffer.from('fake avatar content'),
  34  |     });
  35  | 
  36  |     await page.locator('input#participant_name').fill(participantName);
  37  |     await page.locator('input#ndis_number').fill('987654321');
  38  |     await page.locator('input#date_of_birth').fill('2000-01-01');
  39  |     await page.locator('input#personal_mobile').fill('0411111111');
  40  |     await page.locator('textarea#address').fill('789 Participant Rd, Perth WA');
  41  |     
  42  |     const supportLevel = page.locator('button:has-text("Select support level")');
  43  |     if (await supportLevel.isVisible()) {
  44  |       await supportLevel.click();
  45  |       await page.getByRole('option', { name: /High/i }).click();
  46  |     }
  47  |     
  48  |     await page.getByLabel(/Support Coordinator/i).fill('John Coordinator');
  49  | 
  50  |     // 3. Goals (Sub-entity CRUD)
  51  |     await page.getByText(/Goals/i).first().click({ force: true });
  52  |     await page.getByRole('button', { name: /Add Goal/i }).click({ force: true });
  53  |     await page.locator('textarea#description').or(page.getByLabel(/Goal Description/i)).fill('Independent living skills and social inclusion');
  54  |     await page.getByRole('button', { name: /Save/i, exact: true }).click({ force: true });
  55  |     await expect(page.getByText('social inclusion').first()).toBeVisible();
  56  | 
  57  |     // 4. Behaviour Support
  58  |     await page.getByText(/Behaviour/i).first().click({ force: true });
  59  |     await page.locator('textarea#behaviour_of_concern').or(page.getByLabel(/Behaviour of Concern/i)).fill('Occasional social anxiety in large groups.');
  60  |     await page.locator('input#specialist_name').or(page.getByLabel(/Specialist Name/i)).fill('Dr. Behaviour');
  61  | 
  62  |     // 5. Support Needs (Communication)
  63  |     await page.getByText(/Support Needs/i).first().click({ force: true });
  64  |     await page.locator('textarea#routine').or(page.getByLabel(/Routine/i)).fill('Morning walks, afternoon reading.');
  65  |     const commType = page.locator('button:has-text("Select communication type")');
  66  |     if (await commType.isVisible()) {
  67  |       await commType.click({ force: true });
  68  |       await page.getByRole('option', { name: 'Verbal', exact: true }).first().click({ force: true });
  69  |     }
  70  |     await page.getByLabel(/Communication Type Notes/i).fill('Prefers clear, direct instructions.');
  71  |     await page.locator('textarea#finance_support').fill('Needs assistance with budget management.');
  72  | 
  73  |     // 6. Contacts (Sub-entity CRUD)
  74  |     await page.getByText(/Contacts/i).first().click();
  75  |     await page.getByRole('button', { name: /Add Contact/i }).click();
  76  |     await page.locator('input#contact_name').fill('Jane Doe');
  77  |     await page.getByRole('combobox').click();
  78  |     await page.getByRole('option').first().click();
  79  |     await page.locator('input#phone').fill('0422222222');
  80  |     await page.getByRole('button', { name: /Add to Queue/i }).click();
  81  |     await expect(page.getByText('Jane Doe')).toBeVisible();
  82  | 
  83  |     // 7. Medical Routine
  84  |     await page.getByText(/Medical/i).first().click();
  85  |     await page.locator('input#pharmacy_name').or(page.getByLabel(/Pharmacy Name/i)).fill('Central Pharmacy');
  86  |     await page.locator('input#gp_name').or(page.getByLabel(/GP Name/i)).fill('Dr. Smith');
  87  |     await page.locator('input#psychiatrist_name').or(page.getByLabel(/Psychiatrist Name/i)).fill('Dr. Freud');
  88  | 
  89  |     // 8. Medications (Combobox + sub-entity CRUD)
  90  |     await page.getByText(/Medications/i).first().click();
  91  |     await page.getByRole('button', { name: /Add Medication/i }).click();
  92  |     await page.getByRole('combobox').click();
  93  |     await page.getByRole('option').first().click();
  94  |     await page.getByLabel(/Dosage/i).fill('10mg daily');
  95  |     await page.getByRole('button', { name: /Add to Queue/i }).click();
  96  |     await expect(page.getByText('10mg daily')).toBeVisible();
  97  | 
  98  |     // 9. Documents (File Upload)
  99  |     await page.getByText(/Documents/i).first().click();
> 100 |     const fileChooserPromise = page.waitForEvent('filechooser');
      |                                     ^ TimeoutError: page.waitForEvent: Timeout 15000ms exceeded while waiting for event "filechooser"
  101 |     await page.getByRole('button', { name: /Upload/i }).click();
  102 |     const fileChooser = await fileChooserPromise;
  103 |     await fileChooser.setFiles({
  104 |       name: 'behavior_plan.pdf',
  105 |       mimeType: 'application/pdf',
  106 |       buffer: Buffer.from('fake plan content'),
  107 |     });
  108 |     await expect(page.getByText('behavior_plan.pdf')).toBeVisible();
  109 | 
  110 |     // 10. Hygiene & Routines
  111 |     await page.getByText(/Hygiene/i).first().click();
  112 |     await page.locator('textarea#morning_routine').fill('Wake up at 7am, brush teeth.');
  113 | 
  114 |     // 11. Restrictive Practices
  115 |     await page.getByText(/Practices/i).first().click();
  116 |     await page.locator('textarea#restrictive_practices').fill('None currently authorized.');
  117 | 
  118 |     // 12. Notes
  119 |     await page.getByText(/Notes/i).first().click();
  120 |     await page.locator('textarea#general_notes').fill('Participant is adjusting well to the new environment.');
  121 | 
  122 |     // 13. Final Save & Verify Persistence
  123 |     await page.getByRole('button', { name: /Save Changes/i }).click();
  124 |     await expect(page.getByText(/Changes saved successfully/i)).toBeVisible({ timeout: 20000 });
  125 | 
  126 |     await page.reload();
  127 |     
  128 |     // Verify Persistence
  129 |     await expect(page.locator('input#participant_name')).toHaveValue(participantName);
  130 |     await expect(page.locator('input#ndis_number')).toHaveValue('987654321');
  131 |     
  132 |     await page.getByText(/Goals/i).first().click();
  133 |     await expect(page.getByText('social inclusion').first()).toBeVisible();
  134 |     
  135 |     await page.getByText(/Behaviour/i).first().click();
  136 |     await expect(page.locator('input#specialist_name')).toHaveValue('Dr. Behaviour');
  137 | 
  138 |     await page.getByText(/Support Needs/i).first().click();
  139 |     await expect(page.locator('textarea#finance_support')).toHaveValue('Needs assistance with budget management.');
  140 | 
  141 |     await page.getByText(/Contacts/i).first().click();
  142 |     await expect(page.getByText('Jane Doe')).toBeVisible();
  143 | 
  144 |     await page.getByText(/Hygiene/i).first().click();
  145 |     await expect(page.locator('textarea#morning_routine')).toHaveValue('Wake up at 7am, brush teeth.');
  146 | 
  147 |     await page.getByText(/Practices/i).first().click();
  148 |     await expect(page.locator('textarea#restrictive_practices')).toHaveValue('None currently authorized.');
  149 | 
  150 |     await page.getByText(/Notes/i).first().click();
  151 |     await expect(page.locator('textarea#general_notes')).toHaveValue('Participant is adjusting well to the new environment.');
  152 | 
  153 |     await page.getByText(/Documents/i).first().click();
  154 |     await expect(page.getByText('behavior_plan.pdf')).toBeVisible();
  155 | 
  156 |     // 14. Cleanup (Archive Participant)
  157 |     await page.goto('/participants');
  158 |     const participantRow = page.locator('tr').filter({ hasText: participantName });
  159 |     await participantRow.getByRole('button', { name: /Archive/i }).click();
  160 |     await expect(page.getByText(/Participant archived successfully/i)).toBeVisible();
  161 |   });
  162 | });
  163 | 
```