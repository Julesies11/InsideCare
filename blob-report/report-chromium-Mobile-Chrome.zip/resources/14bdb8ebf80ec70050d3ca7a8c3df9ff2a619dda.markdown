# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: e2e/operations-comprehensive.spec.ts >> Operations Comprehensive >> Admin Operations >> Manage Shift Templates - Full CRUD lifecycle
- Location: tests/e2e/operations-comprehensive.spec.ts:33:5

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('E2E Test Template 1780370085636').first()
Expected: visible
Timeout: 30000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 30000ms
  - waiting for getByText('E2E Test Template 1780370085636').first()

```

```yaml
- region "Notifications alt+T"
- dialog "Add Shift Template":
  - heading "Add Shift Template" [level=2]
  - text: Template Name
  - textbox "Template Name":
    - /placeholder: e.g. Morning
    - text: E2E Test Template 1780370085636
  - text: Short Name
  - textbox "Short Name":
    - /placeholder: e.g. M
    - text: E2ET
  - text: Start Time
  - textbox "Start Time": 07:00
  - text: End Time
  - textbox "End Time": 15:00
  - switch "Active" [checked]
  - text: Active Default Checklists Kitchen Clean
  - checkbox
  - button "Cancel"
  - button "Save Template"
  - button "Close"
```

# Test source

```ts
  1   | import { test, expect } from '@playwright/test';
  2   | 
  3   | /**
  4   |  * Comprehensive tests for Operations: Roster, Checklists, and Timesheets.
  5   |  */
  6   | test.describe('Operations Comprehensive', () => {
  7   |   
  8   |   test.describe('Admin Operations', () => {
  9   |     test.use({ storageState: 'playwright/.auth/admin.json' });
  10  | 
  11  |     test('Roster Board - View and Open Shift Dialog', async ({ page }) => {
  12  |       await page.goto('/roster-board');
  13  |       await expect(page.locator('h1:has-text("Roster Board")')).toBeVisible({ timeout: 30000 });
  14  |       
  15  |       // Look for the calendar container
  16  |       const calendar = page.locator('.rbc-calendar').or(page.locator('.p-6.space-y-6').filter({ hasText: /Today|Week|Month/i }));
  17  |       await expect(calendar.first()).toBeVisible();
  18  | 
  19  |       // Click "Add Shift"
  20  |       const addShiftBtn = page.getByRole('button', { name: /Add Shift/i }).or(page.locator('button:has-text("Add Shift")'));
  21  |       if (await addShiftBtn.first().isVisible()) {
  22  |         await addShiftBtn.first().click();
  23  | 
  24  |         // Verify Shift Dialog
  25  |         const dialog = page.locator('[role="dialog"]');
  26  |         await expect(dialog).toBeVisible();
  27  |         await expect(dialog.getByText(/Shift Details/i).or(dialog.getByText(/Shift/i))).toBeVisible();
  28  |         
  29  |         await dialog.getByRole('button', { name: /Cancel/i }).click();
  30  |       }
  31  |     });
  32  | 
  33  |     test('Manage Shift Templates - Full CRUD lifecycle', async ({ page }) => {
  34  |       await page.goto('/shift-setup');
  35  |       await expect(page.locator('h1:has-text("Shift Templates")')).toBeVisible();
  36  |       
  37  |       // Click Edit for the first available house in the list
  38  |       const editHouseBtn = page.getByRole('button', { name: /Edit/i }).first();
  39  |       await expect(editHouseBtn).toBeVisible();
  40  |       await editHouseBtn.click({ force: true });
  41  |       
  42  |       // Verify we are on the edit page for that house
  43  |       await expect(page).toHaveURL(/\/shift-setup\//, { timeout: 30000 });
  44  |       await expect(page.getByRole('button', { name: /Add Template/i })).toBeVisible();
  45  | 
  46  |       // 1. Create Shift Template
  47  |       const templateName = `E2E Test Template ${Date.now()}`;
  48  |       await page.getByRole('button', { name: /Add Template/i }).click({ force: true });
  49  |       await page.getByLabel(/Template Name/i).fill(templateName);
  50  |       await page.getByLabel(/Short Name/i).fill('E2ET');
  51  |       await page.getByRole('button', { name: /Save Template/i }).click({ force: true });
  52  |       
  53  |       // Wait for success toast to ensure DB sync
  54  |       await expect(page.locator('[data-sonner-toast][data-type="success"]').last()).toContainText(/success|saved|updated/i, { timeout: 30000 });
  55  | 
  56  |       // Verify persistence
> 57  |       await expect(page.getByText(templateName).first()).toBeVisible();
      |                                                          ^ Error: expect(locator).toBeVisible() failed
  58  | 
  59  |       // 2. Edit Shift Template
  60  |       const editedName = `${templateName} Edited`;
  61  |       const templateCard = page.locator('div.bg-white.border.rounded-xl').filter({ hasText: templateName });
  62  |       await templateCard.locator('button[aria-label="edit"]').first().click({ force: true });
  63  |       await page.getByLabel(/Template Name/i).fill(editedName);
  64  |       await page.getByRole('button', { name: /Save Template/i }).click({ force: true });
  65  |       
  66  |       // Wait for success toast
  67  |       await expect(page.locator('[data-sonner-toast][data-type="success"]').last()).toContainText(/success|updated/i, { timeout: 30000 });
  68  | 
  69  |       // Verify persistence
  70  |       await expect(page.getByText(editedName).first()).toBeVisible();
  71  | 
  72  |       // 3. Delete Shift Template
  73  |       // Handle the browser confirm dialog
  74  |       page.once('dialog', dialog => dialog.accept());
  75  |       
  76  |       const editedCard = page.locator('div.bg-white.border.rounded-xl').filter({ hasText: editedName });
  77  |       await editedCard.locator('button[aria-label="delete"]').first().click({ force: true });
  78  |       
  79  |       // Verify it is gone
  80  |       await expect(page.getByText(editedName)).not.toBeVisible();
  81  |     });
  82  | 
  83  |     test('Manage Checklist Templates - Full CRUD lifecycle', async ({ page }) => {
  84  |       await page.goto('/checklist-templates');
  85  |       await expect(page.locator('h1:has-text("Checklist Master")')).toBeVisible();
  86  |       
  87  |       // 1. Create Checklist Template
  88  |       const templateName = `E2E Checklist ${Date.now()}`;
  89  |       await page.getByRole('button', { name: /Create Template/i }).click({ force: true });
  90  |       await page.getByPlaceholder(/e.g. Morning Clinical Routine/i).fill(templateName);
  91  |       
  92  |       await page.getByRole('button', { name: /Add Task/i }).click({ force: true });
  93  |       await page.getByPlaceholder(/e.g. Confirm kitchen cleaning/i).fill('E2E Verification Task');
  94  |       await page.getByRole('button', { name: /Apply Task/i }).click({ force: true });
  95  |       
  96  |       await expect(page.getByText('E2E Verification Task').first()).toBeVisible();
  97  |       await page.getByRole('button', { name: /Create Master Template/i }).click({ force: true });
  98  |       
  99  |       // Wait for success toast
  100 |       await expect(page.locator('[data-sonner-toast]')).toContainText(/success|created|saved/i, { timeout: 30000 });
  101 | 
  102 |       // Verify persistence
  103 |       await expect(page.getByText(templateName).first()).toBeVisible();
  104 | 
  105 |       // 2. Edit Checklist Template
  106 |       const editedName = `${templateName} Edited`;
  107 |       // Find the card with the template name and click Edit
  108 |       const templateCard = page.locator('div.border').filter({ hasText: templateName });
  109 |       await expect(templateCard.first()).toBeVisible({ timeout: 20000 });
  110 |       await templateCard.scrollIntoViewIfNeeded();
  111 |       await templateCard.locator('button[aria-label="edit"]').first().click({ force: true });
  112 | 
  113 |       await page.getByPlaceholder(/e.g. Morning Clinical Routine/i).fill(editedName);
  114 |       await page.getByRole('button', { name: /Update Master Template/i }).click({ force: true });
  115 | 
  116 |       // Wait for success toast
  117 |       await expect(page.locator('[data-sonner-toast][data-type="success"]').last()).toContainText(/success|updated/i, { timeout: 30000 });
  118 | 
  119 |       // Verify persistence
  120 |       await expect(page.getByText(editedName).first()).toBeVisible();
  121 | 
  122 |       // 3. Delete Checklist Template
  123 |       page.once('dialog', dialog => dialog.accept());
  124 |       const editedCard = page.locator('div.border').filter({ hasText: editedName });
  125 |       await editedCard.locator('button[aria-label="delete"]').first().click({ force: true });
  126 |       
  127 |       // Verify it is gone
  128 |       await expect(page.getByText(editedName)).not.toBeVisible();
  129 |     });
  130 |   });
  131 | 
  132 |   test.describe('Staff Operations', () => {
  133 |     test.use({ storageState: 'playwright/.auth/staff.json' });
  134 | 
  135 |     test('Staff Dashboard - Check for active shift or missing timesheets', async ({ page }) => {
  136 |       await page.goto('/my-dashboard');
  137 |       await expect(page.getByText(/Upcoming Schedule/i).first()).toBeVisible();
  138 |       
  139 |       // Look for cards
  140 |       await expect(page.locator('[data-slot="card"]').first().or(page.locator('.card').first())).toBeVisible();
  141 |     });
  142 | 
  143 |     test('Staff Checklists - Sign-off flow', async ({ page }) => {
  144 |       await page.goto('/my-checklists');
  145 |       await expect(page.getByText(/House Checklists/i)).toBeVisible({ timeout: 30000 });
  146 | 
  147 |       // Click on a checklist card if present
  148 |       const firstChecklist = page.locator('.card:has-text("Items")').first().or(page.locator('.card').first());
  149 |       if (await firstChecklist.first().isVisible()) {
  150 |         await firstChecklist.first().click();
  151 |         
  152 |         // In the checklist execution view
  153 |         const completeBtn = page.getByRole('button', { name: /Complete/i }).or(page.getByRole('button', { name: /Finish/i }));
  154 |         if (await completeBtn.first().isVisible()) {
  155 |           await expect(completeBtn.first()).toBeVisible();
  156 |         }
  157 |       }
```