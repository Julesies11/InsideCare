# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: e2e/staff.spec.ts >> Staff Workflows >> Staff can initiate a Leave Request
- Location: tests/e2e/staff.spec.ts:6:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('#leaveType')
Expected: visible
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 15000ms
  - waiting for locator('#leaveType')

```

```yaml
- region "Notifications alt+T"
- img "InsideCare"
- heading "Sign In" [level=1]
- paragraph: Welcome back! Log in with your credentials.
- alert: Development Environment - For testing only
- text: Email
- textbox "Email":
  - /placeholder: Your email
- text: Password
- textbox "Password":
  - /placeholder: Your password
- button
- checkbox "Remember me" [checked]
- text: Remember me
- link "Forgot Password?":
  - /url: /auth/reset-password
- button "Sign In"
- paragraph: Testing & Development
- button "Admin"
- button "Support Worker"
- button "Supervisor"
- button "House Manager"
- button "Director"
- button "Finance Manager"
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | 
  3  | test.describe('Staff Workflows', () => {
  4  |   test.use({ storageState: 'playwright/.auth/staff.json' });
  5  | 
  6  |   test('Staff can initiate a Leave Request', async ({ page }) => {
  7  |     await page.goto('/my-leave/new');
  8  |     
  9  |     // Verify form elements
  10 |     const trigger = page.locator('#leaveType');
> 11 |     await expect(trigger).toBeVisible({ timeout: 15000 });
     |                           ^ Error: expect(locator).toBeVisible() failed
  12 |     
  13 |     // Select a leave type (Annual Leave)
  14 |     await trigger.click();
  15 |     const annualLeaveOption = page.getByRole('option', { name: /Annual Leave/i }).first();
  16 |     await expect(annualLeaveOption).toBeVisible({ timeout: 10000 });
  17 |     await annualLeaveOption.click();
  18 | 
  19 |     // Fill in dates
  20 |     await page.getByLabel(/Start Date/i).fill('2026-06-01');
  21 |     await page.getByLabel(/End Date/i).fill('2026-06-07');
  22 |     await page.getByLabel(/Reason/i).fill('Test leave request');
  23 | 
  24 |     // Submit
  25 |     await page.getByRole('button', { name: /Submit/i }).click();
  26 |     
  27 |     // Check for success toast - using a more specific locator to avoid strict mode violations
  28 |     await expect(page.locator('[data-sonner-toast]')).toContainText(/submitted successfully|request updated/i, { timeout: 15000 });
  29 |     
  30 |     // Should be redirected to leave list
  31 |     await expect(page).toHaveURL(/\/my-leave/);
  32 |   });
  33 | 
  34 |   test('Staff can view their Leave Requests', async ({ page }) => {
  35 |     await page.goto('/my-leave');
  36 |     await expect(page.getByRole('table')).toBeVisible({ timeout: 15000 });
  37 |     // Should see the seeded 'Annual Leave' or the one just created
  38 |     await expect(page.locator('body')).toContainText(/Annual Leave/i);
  39 |   });
  40 | 
  41 |   test('Staff can view their Roster', async ({ page }) => {
  42 |     await page.goto('/my-roster');
  43 |     await expect(page.getByRole('button', { name: /Today/i })).toBeVisible({ timeout: 15000 });
  44 |   });
  45 | 
  46 |   test('Staff can access House Checklists', async ({ page }) => {
  47 |     await page.goto('/my-checklists');
  48 |     // Wait for the main container first
  49 |     await expect(page.locator('#root')).toBeVisible({ timeout: 30000 });
  50 |     // Check for heading or checklist card - using text is often more robust than role + level in complex templates
  51 |     await expect(page.getByText(/House Checklists/i).or(page.locator('.card')).first()).toBeVisible({ timeout: 45000 });
  52 |   });
  53 | 
  54 |   test('Staff can open the Shift Note dialog', async ({ page }) => {
  55 |     await page.goto('/participants/profiles');
  56 |     const noteBtn = page.getByRole('button', { name: /Add Note/i }).or(page.locator('button:has-text("Note")'));
  57 |     if (await noteBtn.first().isVisible()) {
  58 |       await noteBtn.first().click();
  59 |       await expect(page.locator('[role="dialog"]')).toBeVisible();
  60 |     }
  61 |   });
  62 | });
  63 | 
```