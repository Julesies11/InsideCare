# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: e2e/compliance.spec.ts >> Compliance Management >> Staff Compliance Profile - Status Transitions
- Location: tests/e2e/compliance.spec.ts:138:3

# Error details

```
TimeoutError: locator.click: Timeout 30000ms exceeded.
Call log:
  - waiting for getByRole('link', { name: /Compliance/i }).or(locator('a:has-text("Compliance")'))

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - region "Notifications alt+T"
  - generic [ref=e4]:
    - generic [ref=e5]:
      - link "Default Logo" [ref=e6] [cursor=pointer]:
        - /url: /
        - img "Default Logo" [ref=e8]
      - button [ref=e9] [cursor=pointer]:
        - img [ref=e10]
    - menu [ref=e15]:
      - heading "My Dashboard" [level=3] [ref=e17]:
        - button "My Dashboard" [ref=e18] [cursor=pointer]:
          - link "My Dashboard" [ref=e19]:
            - /url: /my-dashboard
            - img
            - generic [ref=e20]: My Dashboard
      - text: Staff Portal
      - heading "House Checklists" [level=3] [ref=e22]:
        - button "House Checklists" [ref=e23] [cursor=pointer]:
          - link "House Checklists" [ref=e24]:
            - /url: /my-checklists
            - img
            - generic [ref=e25]: House Checklists
      - heading "My Roster" [level=3] [ref=e27]:
        - button "My Roster" [ref=e28] [cursor=pointer]:
          - link "My Roster" [ref=e29]:
            - /url: /my-roster
            - img
            - generic [ref=e30]: My Roster
      - heading "My Leave" [level=3] [ref=e32]:
        - button "My Leave" [ref=e33] [cursor=pointer]:
          - link "My Leave" [ref=e34]:
            - /url: /my-leave
            - img
            - generic [ref=e35]: My Leave
      - heading "My Timesheets" [level=3] [ref=e37]:
        - button "My Timesheets" [ref=e38] [cursor=pointer]:
          - link "My Timesheets" [ref=e39]:
            - /url: /my-timesheets
            - img
            - generic [ref=e40]: My Timesheets
      - text: People & Houses
      - heading "Staff" [level=3] [ref=e42]:
        - button "Staff" [expanded] [ref=e43] [cursor=pointer]:
          - link "Staff" [ref=e44]:
            - /url: /staff
            - img
            - generic [ref=e45]: Staff
      - heading "Houses" [level=3] [ref=e47]:
        - button "Houses" [ref=e48] [cursor=pointer]:
          - link "Houses" [ref=e49]:
            - /url: /houses
            - img
            - generic [ref=e50]: Houses
      - heading "Participants" [level=3] [ref=e52]:
        - button "Participants" [ref=e53] [cursor=pointer]:
          - img
          - generic [ref=e54]: Participants
          - img
      - heading "Incidents" [level=3] [ref=e56]:
        - button "Incidents" [ref=e57] [cursor=pointer]:
          - link "Incidents" [ref=e58]:
            - /url: /incidents
            - img
            - generic [ref=e59]: Incidents
      - text: Roster & Staff Scheduling
      - heading "Roster Board" [level=3] [ref=e61]:
        - button "Roster Board" [ref=e62] [cursor=pointer]:
          - link "Roster Board" [ref=e63]:
            - /url: /roster-board
            - img
            - generic [ref=e64]: Roster Board
      - heading "Shift Setup" [level=3] [ref=e66]:
        - button "Shift Setup" [ref=e67] [cursor=pointer]:
          - link "Shift Setup" [ref=e68]:
            - /url: /shift-setup
            - img
            - generic [ref=e69]: Shift Setup
      - heading "Timesheet Approvals" [level=3] [ref=e71]:
        - button "Timesheet Approvals" [ref=e72] [cursor=pointer]:
          - link "Timesheet Approvals" [ref=e73]:
            - /url: /timesheet-approvals
            - img
            - generic [ref=e74]: Timesheet Approvals
      - heading "Leave Approvals" [level=3] [ref=e76]:
        - button "Leave Approvals" [ref=e77] [cursor=pointer]:
          - link "Leave Approvals" [ref=e78]:
            - /url: /leave-approvals
            - img
            - generic [ref=e79]: Leave Approvals
      - text: Administration
      - heading "Access Control" [level=3] [ref=e81]:
        - button "Access Control" [ref=e82] [cursor=pointer]:
          - link "Access Control" [ref=e83]:
            - /url: /access-control
            - img
            - generic [ref=e84]: Access Control
      - heading "Checklist Templates" [level=3] [ref=e86]:
        - button "Checklist Templates" [ref=e87] [cursor=pointer]:
          - link "Checklist Templates" [ref=e88]:
            - /url: /checklist-templates
            - img
            - generic [ref=e89]: Checklist Templates
      - heading "Reporting" [level=3] [ref=e91]:
        - button "Reporting" [ref=e92] [cursor=pointer]:
          - link "Reporting" [ref=e93]:
            - /url: /reporting
            - img
            - generic [ref=e94]: Reporting
      - heading "Compliance" [level=3] [ref=e96]:
        - button "Compliance" [ref=e97] [cursor=pointer]:
          - img
          - generic [ref=e98]: Compliance
          - img
      - heading "Onboarding" [level=3] [ref=e100]:
        - button "Onboarding" [ref=e101] [cursor=pointer]:
          - img
          - generic [ref=e102]: Onboarding
          - img
      - heading "Activity Log" [level=3] [ref=e104]:
        - button "Activity Log" [ref=e105] [cursor=pointer]:
          - link "Activity Log" [ref=e106]:
            - /url: /activity-log
            - img
            - generic [ref=e107]: Activity Log
  - generic [ref=e108]:
    - banner [ref=e109]:
      - generic [ref=e112]:
        - button [ref=e113] [cursor=pointer]:
          - img [ref=e114]
        - img "avatar" [ref=e120] [cursor=pointer]
    - main [ref=e121]:
      - generic [ref=e124]:
        - generic [ref=e126]:
          - button "Back" [ref=e127] [cursor=pointer]:
            - img [ref=e128]
            - text: Back
          - generic [ref=e131]:
            - heading "Staff Details" [level=1] [ref=e132]
            - generic [ref=e133]:
              - generic [ref=e134]: Portal Active
              - img [ref=e135]
        - generic [ref=e139]:
          - button "Save Changes" [disabled]
          - button "Deactivate" [ref=e140] [cursor=pointer]:
            - img [ref=e141]
            - text: Deactivate
          - button [ref=e144] [cursor=pointer]:
            - img [ref=e145]
      - generic [ref=e150]:
        - generic [ref=e154]:
          - generic [ref=e155] [cursor=pointer]: Personal Details
          - generic [ref=e156] [cursor=pointer]: Employment Details
          - generic [ref=e157] [cursor=pointer]: Onboarding
          - generic [ref=e158] [cursor=pointer]: Availability
          - generic [ref=e159] [cursor=pointer]: Emergency Contact
          - generic [ref=e160] [cursor=pointer]: Compliance
          - generic [ref=e161] [cursor=pointer]: Training
          - generic [ref=e162] [cursor=pointer]: Documents
          - generic [ref=e163] [cursor=pointer]: Roster
          - generic [ref=e164] [cursor=pointer]: Leave
          - generic [ref=e165] [cursor=pointer]: Warnings
          - generic [ref=e166] [cursor=pointer]: Activity Log
        - generic [ref=e168]:
          - generic [ref=e169]:
            - heading "Personal Details" [level=3] [ref=e171]
            - generic [ref=e172]:
              - generic [ref=e174]:
                - generic [ref=e175]: Profile Photo
                - generic [ref=e176]:
                  - generic [ref=e177] [cursor=pointer]:
                    - button [ref=e178]:
                      - img [ref=e179]
                    - generic [ref=e182]:
                      - img "avatar" [ref=e183]
                      - img [ref=e185]
                  - paragraph [ref=e188]: Click the photo to change it
              - generic [ref=e190]:
                - generic [ref=e191]: Full Name *
                - textbox "Full Name *" [ref=e193]:
                  - /placeholder: Staff member name
                  - text: Demo Admin
              - generic [ref=e195]:
                - generic [ref=e196]: Email *
                - textbox "Email *" [ref=e198]:
                  - /placeholder: staff@example.com
                  - text: julian.gibbings+admin@gmail.com
              - generic [ref=e200]:
                - generic [ref=e201]: Phone
                - textbox "+1 (555) 000-0000" [ref=e202]: "1234"
              - generic [ref=e204]:
                - generic [ref=e205]: Date of Birth
                - textbox [ref=e206]
              - generic [ref=e208]:
                - generic [ref=e209]: Address
                - textbox "Street address, city, state, postal code" [ref=e210]
              - generic [ref=e212]:
                - generic [ref=e213]: Hobbies
                - textbox "Staff member hobbies and interests" [ref=e214]
              - generic [ref=e216]:
                - generic [ref=e217]: Allergies
                - textbox "Staff member allergies" [ref=e218]
          - generic [ref=e219]:
            - heading "Employment Details" [level=3] [ref=e221]
            - generic [ref=e222]:
              - generic [ref=e224]:
                - generic [ref=e225]: Role
                - generic [ref=e226]:
                  - combobox [ref=e227] [cursor=pointer]:
                    - generic [ref=e228]: Admin
                    - img [ref=e229]
                  - button "Manage role list" [ref=e231] [cursor=pointer]:
                    - img [ref=e232]
              - generic [ref=e236]:
                - generic [ref=e237]: Department
                - generic [ref=e238]:
                  - combobox [ref=e239] [cursor=pointer]:
                    - generic [ref=e240]: Management
                    - img [ref=e241]
                  - button "Manage department list" [ref=e243] [cursor=pointer]:
                    - img [ref=e244]
              - generic [ref=e248]:
                - generic [ref=e249]: Employment Type
                - generic [ref=e250]:
                  - combobox [ref=e251] [cursor=pointer]:
                    - generic [ref=e252]: Select employment type...
                    - img [ref=e253]
                  - button "Manage employment type list" [ref=e255] [cursor=pointer]:
                    - img [ref=e256]
              - generic [ref=e259]:
                - generic [ref=e260]: Manager
                - combobox [ref=e262]:
                  - generic: Select manager (optional)
                  - img [ref=e263]
              - generic [ref=e265]:
                - generic [ref=e266]: Status
                - combobox [ref=e268]:
                  - generic: Active
                  - img [ref=e269]
              - generic [ref=e272]:
                - generic [ref=e273]: Hire Date
                - textbox [ref=e274]
              - generic [ref=e276]:
                - generic [ref=e277]: Separation Date
                - textbox [ref=e278]
              - generic [ref=e280]:
                - generic [ref=e281]: Any Other Notes
                - textbox "Additional notes about staff member" [ref=e282]
          - generic [ref=e283]:
            - heading "Onboarding Checklist" [level=3] [ref=e285]
            - table [ref=e289]:
              - rowgroup [ref=e290]:
                - row "Done Task Comments" [ref=e291]:
                  - columnheader "Done" [ref=e292]
                  - columnheader "Task" [ref=e293]
                  - columnheader "Comments" [ref=e294]
              - rowgroup [ref=e295]:
                - row "Interview to do soon" [ref=e296]:
                  - cell [ref=e297]:
                    - checkbox [ref=e298]
                  - cell "Interview" [ref=e299]:
                    - generic [ref=e301]: Interview
                  - cell "to do soon" [ref=e302]:
                    - textbox "Add comments..." [ref=e303]: to do soon
                - row "Send onboarding email" [ref=e304]:
                  - cell [ref=e305]:
                    - checkbox [ref=e306]
                  - cell "Send onboarding email" [ref=e307]:
                    - generic [ref=e309]: Send onboarding email
                  - cell [ref=e310]:
                    - textbox "Add comments..." [ref=e311]
                - row "Gather documents (inc onboarding, compliance, training, qualifications)" [ref=e312]:
                  - cell [ref=e313]:
                    - checkbox [ref=e314]
                  - cell "Gather documents (inc onboarding, compliance, training, qualifications)" [ref=e315]:
                    - generic [ref=e317]: Gather documents (inc onboarding, compliance, training, qualifications)
                  - cell [ref=e318]:
                    - textbox "Add comments..." [ref=e319]
                - row "Assign training if relevant" [ref=e320]:
                  - cell [ref=e321]:
                    - checkbox [ref=e322]
                  - cell "Assign training if relevant" [ref=e323]:
                    - generic [ref=e325]: Assign training if relevant
                  - cell [ref=e326]:
                    - textbox "Add comments..." [ref=e327]
                - row "Set up employee profile" [ref=e328]:
                  - cell [ref=e329]:
                    - checkbox [ref=e330]
                  - cell "Set up employee profile" [ref=e331]:
                    - generic [ref=e333]: Set up employee profile
                  - cell [ref=e334]:
                    - textbox "Add comments..." [ref=e335]
                - row "Employee induction (including policies and procedures) testing" [ref=e336]:
                  - cell [ref=e337]:
                    - checkbox [checked] [ref=e338]:
                      - generic:
                        - img
                  - cell "Employee induction (including policies and procedures)" [ref=e339]:
                    - generic [ref=e341]: Employee induction (including policies and procedures)
                  - cell "testing" [ref=e342]:
                    - textbox "Add comments..." [ref=e343]: testing
                - row "test" [ref=e344]:
                  - cell [ref=e345]:
                    - checkbox [ref=e346]
                  - cell "test" [ref=e347]:
                    - generic [ref=e349]: test
                  - cell [ref=e350]:
                    - textbox "Add comments..." [ref=e351]
          - generic [ref=e352]:
            - heading "Availability" [level=3] [ref=e354]
            - generic [ref=e357]:
              - generic [ref=e358]: Availability Schedule
              - textbox "Availability Schedule" [ref=e359]:
                - /placeholder: Staff availability schedule (e.g., Monday 9am-5pm, etc.)
          - generic [ref=e360]:
            - heading "Emergency Contact" [level=3] [ref=e362]
            - generic [ref=e363]:
              - generic [ref=e365]:
                - generic [ref=e366]: Contact Name
                - textbox "Emergency contact name" [ref=e367]
              - generic [ref=e369]:
                - generic [ref=e370]: Contact Phone
                - textbox "+1 (555) 000-0000" [ref=e371]
          - generic [ref=e372]:
            - heading "Compliance Tracking" [level=3] [ref=e374]
            - table [ref=e378]:
              - rowgroup [ref=e379]:
                - row "Requirement Workflow Status Expiry Date Compliance" [ref=e380]:
                  - columnheader "Requirement" [ref=e381]
                  - columnheader "Workflow Status" [ref=e382]
                  - columnheader "Expiry Date" [ref=e383]
                  - columnheader "Compliance" [ref=e384]
              - rowgroup [ref=e385]:
                - 'row "100 Points of ID Verification of identity using the standard 100-point ID checklist (primary and secondary documents). ... 70 pts verified (Continue Verification) Sighted ID Documents: +70 Australian Passport Ref: 1234 Expiry 2026-06-24 View Complete In Progress N/A Started: 6/10/2026 by Demo Admin 2026-06-24 in progress" [ref=e386]':
                  - 'cell "100 Points of ID Verification of identity using the standard 100-point ID checklist (primary and secondary documents). ... 70 pts verified (Continue Verification) Sighted ID Documents: +70 Australian Passport Ref: 1234 Expiry 2026-06-24 View" [ref=e387]':
                    - generic [ref=e388]:
                      - generic [ref=e390]: 100 Points of ID
                      - generic [ref=e391]: Verification of identity using the standard 100-point ID checklist (primary and secondary documents).
                      - button "... 70 pts verified (Continue Verification)" [ref=e393] [cursor=pointer]:
                        - generic [ref=e394]:
                          - generic [ref=e395]: ...
                          - text: 70 pts verified
                        - generic [ref=e396]: (Continue Verification)
                      - generic [ref=e397]:
                        - generic [ref=e398]: "Sighted ID Documents:"
                        - generic [ref=e400]:
                          - generic [ref=e401]:
                            - generic [ref=e403]: "+70"
                            - generic [ref=e404]:
                              - generic [ref=e405]: Australian Passport
                              - generic [ref=e406]: "Ref: 1234"
                          - generic [ref=e407]:
                            - generic [ref=e408]:
                              - generic [ref=e409]: Expiry
                              - generic [ref=e410]: 2026-06-24
                            - button "View" [ref=e411]:
                              - img [ref=e412]
                              - text: View
                  - 'cell "Complete In Progress N/A Started: 6/10/2026 by Demo Admin" [ref=e415]':
                    - generic [ref=e416]:
                      - generic [ref=e417]:
                        - button "Complete" [ref=e418]
                        - button "In Progress" [ref=e419]
                        - button "N/A" [ref=e420]
                      - generic [ref=e421]:
                        - generic [ref=e422]: "Started: 6/10/2026"
                        - generic [ref=e423]: by Demo Admin
                  - cell "2026-06-24" [ref=e424]:
                    - textbox [disabled] [ref=e425]: 2026-06-24
                  - cell "in progress" [ref=e426]:
                    - generic [ref=e427]: in progress
                - 'row "Comprehensive Car Insurance Comprehensive vehicle insurance for staff operating transport. This requirement has been marked as Not Applicable for this staff member. Please provide a reason in the comments field. Complete In Progress N/A Marked N/A: 6/10/2026 by Demo Admin not applicable" [ref=e428]':
                  - cell "Comprehensive Car Insurance Comprehensive vehicle insurance for staff operating transport. This requirement has been marked as Not Applicable for this staff member. Please provide a reason in the comments field." [ref=e429]:
                    - generic [ref=e430]:
                      - generic [ref=e432]: Comprehensive Car Insurance
                      - generic [ref=e433]: Comprehensive vehicle insurance for staff operating transport.
                      - paragraph [ref=e435]:
                        - text: This requirement has been marked as
                        - strong [ref=e436]: Not Applicable
                        - text: for this staff member.
                        - generic [ref=e437]: Please provide a reason in the comments field.
                  - 'cell "Complete In Progress N/A Marked N/A: 6/10/2026 by Demo Admin" [ref=e439]':
                    - generic [ref=e440]:
                      - generic [ref=e441]:
                        - button "Complete" [ref=e442]
                        - button "In Progress" [ref=e443]
                        - button "N/A" [ref=e444]
                      - generic [ref=e445]:
                        - generic [ref=e446]: "Marked N/A: 6/10/2026"
                        - generic [ref=e447]: by Demo Admin
                  - cell [ref=e448]:
                    - textbox [disabled] [ref=e449]
                  - cell "not applicable" [ref=e450]:
                    - generic [ref=e451]: not applicable
                - row "Expiry-Test-1781155539650 Complete In Progress N/A - Missing" [ref=e452]:
                  - cell "Expiry-Test-1781155539650" [ref=e453]:
                    - generic [ref=e456]: Expiry-Test-1781155539650
                  - cell "Complete In Progress N/A" [ref=e457]:
                    - generic [ref=e459]:
                      - button "Complete" [ref=e460]
                      - button "In Progress" [ref=e461]
                      - button "N/A" [ref=e462]
                  - cell "-" [ref=e463]
                  - cell "Missing" [ref=e464]:
                    - generic [ref=e465]: Missing
                - 'row "NDIS Code of Conduct Agreement and understanding of NDIS Code of Conduct. Comments something here Complete In Progress N/A Completed: 6/10/2026 by Demo Admin - complete" [ref=e466]':
                  - cell "NDIS Code of Conduct Agreement and understanding of NDIS Code of Conduct. Comments something here" [ref=e467]:
                    - generic [ref=e468]:
                      - generic [ref=e470]: NDIS Code of Conduct
                      - generic [ref=e471]: Agreement and understanding of NDIS Code of Conduct.
                      - generic [ref=e474]:
                        - text: Comments
                        - textbox "Enter any additional notes..." [ref=e475]: something here
                  - 'cell "Complete In Progress N/A Completed: 6/10/2026 by Demo Admin" [ref=e476]':
                    - generic [ref=e477]:
                      - generic [ref=e478]:
                        - button "Complete" [ref=e479]
                        - button "In Progress" [ref=e480]
                        - button "N/A" [ref=e481]
                      - generic [ref=e482]:
                        - generic [ref=e483]: "Completed: 6/10/2026"
                        - generic [ref=e484]: by Demo Admin
                  - cell "-" [ref=e485]
                  - cell "complete" [ref=e486]:
                    - generic [ref=e487]: complete
                - 'row "NDIS Infection Control Training Infection control training specifically tailored for NDIS support workers. Comments about to do course Attachments No files attached Add Attachment Complete In Progress N/A Started: 6/10/2026 by Demo Admin in progress" [ref=e488]':
                  - cell "NDIS Infection Control Training Infection control training specifically tailored for NDIS support workers. Comments about to do course Attachments No files attached Add Attachment" [ref=e489]:
                    - generic [ref=e490]:
                      - generic [ref=e492]: NDIS Infection Control Training
                      - generic [ref=e493]: Infection control training specifically tailored for NDIS support workers.
                      - generic [ref=e494]:
                        - generic [ref=e496]:
                          - text: Comments
                          - textbox "Enter any additional notes..." [ref=e497]: about to do course
                        - generic [ref=e498]:
                          - generic [ref=e499]: Attachments
                          - generic [ref=e500]:
                            - generic [ref=e501]: No files attached
                            - button "Add Attachment" [ref=e503] [cursor=pointer]:
                              - img [ref=e504]
                              - text: Add Attachment
                  - 'cell "Complete In Progress N/A Started: 6/10/2026 by Demo Admin" [ref=e505]':
                    - generic [ref=e506]:
                      - generic [ref=e507]:
                        - button "Complete" [ref=e508]
                        - button "In Progress" [ref=e509]
                        - button "N/A" [ref=e510]
                      - generic [ref=e511]:
                        - generic [ref=e512]: "Started: 6/10/2026"
                        - generic [ref=e513]: by Demo Admin
                  - cell [ref=e514]:
                    - textbox [ref=e515]
                  - cell "in progress" [ref=e516]:
                    - generic [ref=e517]: in progress
                - row "NDIS Orientation Module NDIS Worker Orientation Module training completion. Complete In Progress N/A Missing" [ref=e518]:
                  - cell "NDIS Orientation Module NDIS Worker Orientation Module training completion." [ref=e519]:
                    - generic [ref=e520]:
                      - generic [ref=e522]: NDIS Orientation Module
                      - generic [ref=e523]: NDIS Worker Orientation Module training completion.
                  - cell "Complete In Progress N/A" [ref=e524]:
                    - generic [ref=e526]:
                      - button "Complete" [ref=e527]
                      - button "In Progress" [ref=e528]
                      - button "N/A" [ref=e529]
                  - cell [ref=e530]:
                    - textbox [disabled] [ref=e531]
                  - cell "Missing" [ref=e532]:
                    - generic [ref=e533]: Missing
                - row "NDIS Supporting Safe and Enjoyable Meals Module Complete In Progress N/A Missing" [ref=e534]:
                  - cell "NDIS Supporting Safe and Enjoyable Meals Module" [ref=e535]:
                    - generic [ref=e538]: NDIS Supporting Safe and Enjoyable Meals Module
                  - cell "Complete In Progress N/A" [ref=e539]:
                    - generic [ref=e541]:
                      - button "Complete" [ref=e542]
                      - button "In Progress" [ref=e543]
                      - button "N/A" [ref=e544]
                  - cell [ref=e545]:
                    - textbox [disabled] [ref=e546]
                  - cell "Missing" [ref=e547]:
                    - generic [ref=e548]: Missing
                - 'row "NDIS Worker Screening Check Mandatory NDIS screening check for support workers. This requirement has been marked as Not Applicable for this staff member. Please provide a reason in the comments field. Complete In Progress N/A Marked N/A: 6/10/2026 by Demo Admin not applicable" [ref=e549]':
                  - cell "NDIS Worker Screening Check Mandatory NDIS screening check for support workers. This requirement has been marked as Not Applicable for this staff member. Please provide a reason in the comments field." [ref=e550]:
                    - generic [ref=e551]:
                      - generic [ref=e553]: NDIS Worker Screening Check
                      - generic [ref=e554]: Mandatory NDIS screening check for support workers.
                      - paragraph [ref=e556]:
                        - text: This requirement has been marked as
                        - strong [ref=e557]: Not Applicable
                        - text: for this staff member.
                        - generic [ref=e558]: Please provide a reason in the comments field.
                  - 'cell "Complete In Progress N/A Marked N/A: 6/10/2026 by Demo Admin" [ref=e560]':
                    - generic [ref=e561]:
                      - generic [ref=e562]:
                        - button "Complete" [ref=e563]
                        - button "In Progress" [ref=e564]
                        - button "N/A" [ref=e565]
                      - generic [ref=e566]:
                        - generic [ref=e567]: "Marked N/A: 6/10/2026"
                        - generic [ref=e568]: by Demo Admin
                  - cell [ref=e569]:
                    - textbox [disabled] [ref=e570]
                  - cell "not applicable" [ref=e571]:
                    - generic [ref=e572]: not applicable
                - row "Resume, Reference Check & Other Employment Complete In Progress N/A - Missing" [ref=e573]:
                  - cell "Resume, Reference Check & Other Employment" [ref=e574]:
                    - generic [ref=e577]: Resume, Reference Check & Other Employment
                  - cell "Complete In Progress N/A" [ref=e578]:
                    - generic [ref=e580]:
                      - button "Complete" [ref=e581]
                      - button "In Progress" [ref=e582]
                      - button "N/A" [ref=e583]
                  - cell "-" [ref=e584]
                  - cell "Missing" [ref=e585]:
                    - generic [ref=e586]: Missing
                - row "Working Rights Do they have working rights in Australia? Complete In Progress N/A Missing" [ref=e587]:
                  - cell "Working Rights Do they have working rights in Australia?" [ref=e588]:
                    - generic [ref=e589]:
                      - generic [ref=e591]: Working Rights
                      - generic [ref=e592]: Do they have working rights in Australia?
                  - cell "Complete In Progress N/A" [ref=e593]:
                    - generic [ref=e595]:
                      - button "Complete" [ref=e596]
                      - button "In Progress" [ref=e597]
                      - button "N/A" [ref=e598]
                  - cell [ref=e599]:
                    - textbox [disabled] [ref=e600]
                  - cell "Missing" [ref=e601]:
                    - generic [ref=e602]: Missing
          - generic [ref=e603]:
            - generic [ref=e604]:
              - heading "Training" [level=3] [ref=e605]
              - button "Add Training" [ref=e606] [cursor=pointer]:
                - img [ref=e607]
                - text: Add Training
            - generic [ref=e609]: No training records available
          - generic [ref=e610]:
            - generic [ref=e611]:
              - heading "Documents" [level=3] [ref=e612]
              - generic [ref=e613]:
                - generic [ref=e614]:
                  - button "Grid View" [ref=e615] [cursor=pointer]:
                    - img [ref=e616]
                  - button "Table View (Admin Only)" [ref=e621] [cursor=pointer]:
                    - img [ref=e622]
                - button "Upload Document" [ref=e623] [cursor=pointer]:
                  - img [ref=e624]
                  - text: Upload Document
            - generic [ref=e626]:
              - generic "Click to view" [ref=e627] [cursor=pointer]:
                - img "file icon" [ref=e629]
                - generic "simpsons background.jpeg" [ref=e630]
                - generic [ref=e631]:
                  - button " " [ref=e632]:
                    - generic [ref=e633]:  
                  - button " " [ref=e634]:
                    - generic [ref=e635]:  
              - generic "Click to view" [ref=e636] [cursor=pointer]:
                - img "file icon" [ref=e638]
                - generic "Where-To-See-Turtles-In-Australia.jpg" [ref=e639]
                - generic [ref=e640]:
                  - button " " [ref=e641]:
                    - generic [ref=e642]:  
                  - button " " [ref=e643]:
                    - generic [ref=e644]:  
              - generic "Click to view" [ref=e645] [cursor=pointer]:
                - img "file icon" [ref=e647]
                - generic "110608.jpg" [ref=e648]
                - generic [ref=e649]:
                  - button " " [ref=e650]:
                    - generic [ref=e651]:  
                  - button " " [ref=e652]:
                    - generic [ref=e653]:  
              - generic "Click to view" [ref=e654] [cursor=pointer]:
                - img "file icon" [ref=e656]
                - generic "star-wars-backgrounds-37.jpeg" [ref=e657]
                - generic [ref=e658]:
                  - button " " [ref=e659]:
                    - generic [ref=e660]:  
                  - button " " [ref=e661]:
                    - generic [ref=e662]:  
              - generic "Click to view" [ref=e663] [cursor=pointer]:
                - generic [ref=e664]:
                  - img "file icon" [ref=e665]
                  - img [ref=e667]
                - generic "beach.jpeg" [ref=e669]
                - generic [ref=e670]:
                  - button " " [ref=e671]:
                    - generic [ref=e672]:  
                  - button " " [ref=e673]:
                    - generic [ref=e674]:  
          - generic [ref=e675]:
            - heading "Roster" [level=3] [ref=e677]
            - generic [ref=e678]:
              - generic [ref=e679]:
                - generic [ref=e680]:
                  - generic [ref=e681]:
                    - button "Today" [ref=e682] [cursor=pointer]
                    - button "Week" [ref=e683] [cursor=pointer]
                    - button "Month" [ref=e684] [cursor=pointer]
                  - generic [ref=e685]:
                    - button [ref=e686] [cursor=pointer]:
                      - img [ref=e687]
                    - paragraph [ref=e690]: Jun 8 – Jun 14, 2026
                    - button [ref=e691] [cursor=pointer]:
                      - img [ref=e692]
                - generic [ref=e694]:
                  - generic [ref=e695]:
                    - switch "Leave" [checked] [ref=e696] [cursor=pointer]
                    - generic [ref=e697] [cursor=pointer]: Leave
                  - generic [ref=e698]:
                    - switch "Meetings" [ref=e699] [cursor=pointer]
                    - generic [ref=e700] [cursor=pointer]: Meetings
              - generic [ref=e702]:
                - generic [ref=e703]:
                  - generic [ref=e704] [cursor=pointer]:
                    - paragraph [ref=e705]: Mon
                    - paragraph [ref=e706]: "8"
                    - button [ref=e707]:
                      - img [ref=e708]
                  - generic [ref=e710] [cursor=pointer]: No shifts
                - generic [ref=e711]:
                  - generic [ref=e712] [cursor=pointer]:
                    - paragraph [ref=e713]: Tue
                    - paragraph [ref=e714]: "9"
                    - button [ref=e715]:
                      - img [ref=e716]
                  - generic [ref=e718] [cursor=pointer]: No shifts
                - generic [ref=e719]:
                  - generic [ref=e720] [cursor=pointer]:
                    - paragraph [ref=e721]: Wed
                    - paragraph [ref=e722]: "10"
                    - button [ref=e723]:
                      - img [ref=e724]
                  - generic [ref=e726] [cursor=pointer]: No shifts
                - generic [ref=e727]:
                  - generic [ref=e728] [cursor=pointer]:
                    - paragraph [ref=e729]: Thu
                    - paragraph [ref=e730]: "11"
                    - button [ref=e731]:
                      - img [ref=e732]
                  - generic [ref=e734] [cursor=pointer]: No shifts
                - generic [ref=e735]:
                  - generic [ref=e736] [cursor=pointer]:
                    - paragraph [ref=e737]: Fri
                    - paragraph [ref=e738]: "12"
                    - button [ref=e739]:
                      - img [ref=e740]
                  - generic [ref=e742] [cursor=pointer]: No shifts
                - generic [ref=e743]:
                  - generic [ref=e744] [cursor=pointer]:
                    - paragraph [ref=e745]: Sat
                    - paragraph [ref=e746]: "13"
                    - button [ref=e747]:
                      - img [ref=e748]
                  - generic [ref=e750] [cursor=pointer]: No shifts
                - generic [ref=e751]:
                  - generic [ref=e752] [cursor=pointer]:
                    - paragraph [ref=e753]: Sun
                    - paragraph [ref=e754]: "14"
                    - button [ref=e755]:
                      - img [ref=e756]
                  - generic [ref=e758] [cursor=pointer]: No shifts
          - generic [ref=e759]:
            - heading "Leave" [level=3] [ref=e761]
            - paragraph [ref=e764]: Leave Management section coming soon.
          - generic [ref=e765]:
            - heading "Warnings" [level=3] [ref=e767]
            - paragraph [ref=e770]: Staff Warnings section coming soon.
          - generic [ref=e771]:
            - heading "Activity Log" [level=3] [ref=e773]
            - generic [ref=e775]:
              - generic [ref=e776]:
                - img [ref=e779]
                - generic [ref=e783]:
                  - generic [ref=e784]: Updated Staff Compliance
                  - generic [ref=e785]:
                    - generic [ref=e786]: about 22 hours ago
                    - generic [ref=e787]:
                      - generic [ref=e788]: •
                      - img "avatar" [ref=e791]
                      - generic [ref=e792]: by Demo Admin
              - generic [ref=e793]:
                - img [ref=e796]
                - generic [ref=e798]:
                  - generic [ref=e799]: Added Staff Compliance "NDIS Infection Control Training"
                  - generic [ref=e800]:
                    - generic [ref=e801]: about 22 hours ago
                    - generic [ref=e802]:
                      - generic [ref=e803]: •
                      - img "avatar" [ref=e806]
                      - generic [ref=e807]: by Demo Admin
              - generic [ref=e808]:
                - img [ref=e811]
                - generic [ref=e813]:
                  - generic [ref=e814]: Added Staff Compliance "NDIS Code of Conduct"
                  - generic [ref=e815]:
                    - generic [ref=e816]: about 22 hours ago
                    - generic [ref=e817]:
                      - generic [ref=e818]: •
                      - img "avatar" [ref=e821]
                      - generic [ref=e822]: by Demo Admin
              - generic [ref=e823]:
                - img [ref=e826]
                - generic [ref=e828]:
                  - generic [ref=e829]: Added Staff Compliance "Comprehensive Car Insurance"
                  - generic [ref=e830]:
                    - generic [ref=e831]: about 22 hours ago
                    - generic [ref=e832]:
                      - generic [ref=e833]: •
                      - img "avatar" [ref=e836]
                      - generic [ref=e837]: by Demo Admin
              - generic [ref=e838]:
                - img [ref=e841]
                - generic [ref=e843]:
                  - generic [ref=e844]: Added Staff Compliance "NDIS Worker Screening Check"
                  - generic [ref=e845]:
                    - generic [ref=e846]: about 23 hours ago
                    - generic [ref=e847]:
                      - generic [ref=e848]: •
                      - img "avatar" [ref=e851]
                      - generic [ref=e852]: by Demo Admin
              - generic [ref=e853]:
                - img [ref=e856]
                - generic [ref=e860]:
                  - generic [ref=e861]: Updated Staff Compliance
                  - generic [ref=e862]:
                    - generic [ref=e863]: 1 day ago
                    - generic [ref=e864]:
                      - generic [ref=e865]: •
                      - generic [ref=e867]: S
                      - generic [ref=e868]: by System
              - generic [ref=e869]:
                - img [ref=e872]
                - generic [ref=e876]:
                  - generic [ref=e877]: Updated Staff Compliance
                  - generic [ref=e878]:
                    - generic [ref=e879]: 1 day ago
                    - generic [ref=e880]:
                      - generic [ref=e881]: •
                      - generic [ref=e883]: S
                      - generic [ref=e884]: by System
              - generic [ref=e885]:
                - img [ref=e888]
                - generic [ref=e890]:
                  - generic [ref=e891]: Added Staff Compliance "100 Points of ID"
                  - generic [ref=e892]:
                    - generic [ref=e893]: 2 days ago
                    - generic [ref=e894]:
                      - generic [ref=e895]: •
                      - img "avatar" [ref=e898]
                      - generic [ref=e899]: by Demo Admin
              - generic [ref=e900]:
                - img [ref=e903]
                - generic [ref=e905]:
                  - generic [ref=e906]: Added Document "simpsons background.jpeg"
                  - generic [ref=e907]:
                    - generic [ref=e908]: 2 days ago
                    - generic [ref=e909]:
                      - generic [ref=e910]: •
                      - img "avatar" [ref=e913]
                      - generic [ref=e914]: by Demo Admin
              - generic [ref=e915]:
                - img [ref=e917]
                - generic [ref=e919]:
                  - generic [ref=e920]: Added Staff Compliance "Drivers License"
                  - generic [ref=e921]:
                    - generic [ref=e922]: 5 days ago
                    - generic [ref=e923]:
                      - generic [ref=e924]: •
                      - img "avatar" [ref=e927]
                      - generic [ref=e928]: by Demo Admin
            - button "All-time Activities" [ref=e930] [cursor=pointer]
    - contentinfo [ref=e932]:
      - generic [ref=e936]: 2026 © InsideCare. All rights reserved.
```

# Test source

```ts
  52  |       await expect(page).toHaveURL(/tab=compliance/);
  53  |     }
  54  |   });
  55  | 
  56  |   test('Admin can manage Compliance Settings (Master List)', async ({
  57  |     page,
  58  |   }) => {
  59  |     await page.goto('/admin/compliance-settings');
  60  |     await expect(page.locator('h1')).toContainText(/Compliance Settings/i);
  61  | 
  62  |     // 1. Add New Compliance Type
  63  |     await page.getByRole('button', { name: /Add Compliance Type/i }).click();
  64  |     await expect(
  65  |       page.getByText(/Add Compliance Type/i, { exact: false }),
  66  |     ).toBeVisible();
  67  | 
  68  |     const typeName = `E2E-Requirement-${Date.now()}`;
  69  |     await page.locator('#type-name').fill(typeName);
  70  |     await page.locator('#type-desc').fill('Automated Test Requirement');
  71  | 
  72  |     // Toggle switches
  73  |     await page.locator('#is-global').click(); // Make global
  74  | 
  75  |     await page.getByRole('button', { name: /Save Changes/i }).click();
  76  | 
  77  |     // Verify success toast
  78  |     await expect(page.locator('[data-sonner-toast]')).toContainText(
  79  |       /added successfully/i,
  80  |     );
  81  |     await expect(page.getByText(typeName)).toBeVisible();
  82  | 
  83  |     // 2. Edit existing type
  84  |     const editBtn = page
  85  |       .locator('tr', { hasText: typeName })
  86  |       .locator('button')
  87  |       .first();
  88  |     await editBtn.click();
  89  |     await page.locator('#type-desc').fill('Updated Description');
  90  |     await page.getByRole('button', { name: /Save Changes/i }).click();
  91  |     await expect(page.locator('[data-sonner-toast]')).toContainText(
  92  |       /updated successfully/i,
  93  |     );
  94  | 
  95  |     // 3. Deactivate type
  96  |     const deactivateBtn = page
  97  |       .locator('tr', { hasText: typeName })
  98  |       .getByRole('button', { name: /Deactivate/i });
  99  |     await deactivateBtn.click();
  100 |     await expect(page.locator('[data-sonner-toast]')).toContainText(
  101 |       /deactivated successfully/i,
  102 |     );
  103 |     await expect(
  104 |       page.locator('tr', { hasText: typeName }).getByText(/Inactive/i),
  105 |     ).toBeVisible();
  106 |   });
  107 | 
  108 |   test('Admin can manage ID Document Types', async ({ page }) => {
  109 |     await page.goto('/admin/compliance-settings');
  110 |     await page.getByRole('tab', { name: /100 Points of ID Config/i }).click();
  111 | 
  112 |     // 1. Add New ID Doc Type
  113 |     await page.getByRole('button', { name: /Add ID Document Type/i }).click();
  114 |     const docName = `E2E-ID-${Date.now()}`;
  115 |     await page.locator('#doc-name').fill(docName);
  116 |     await page.locator('#doc-points').fill('50');
  117 | 
  118 |     // Select category via Radix Select
  119 |     await page.locator('#doc-category').click();
  120 |     await page.getByRole('option', { name: /Secondary/i }).click();
  121 | 
  122 |     await page.getByRole('button', { name: /Save Changes/i }).click();
  123 |     await expect(page.locator('[data-sonner-toast]')).toContainText(
  124 |       /added successfully/i,
  125 |     );
  126 |     await expect(page.getByText(docName)).toBeVisible();
  127 | 
  128 |     // 2. Deactivate ID Doc Type
  129 |     const deactivateBtn = page
  130 |       .locator('tr', { hasText: docName })
  131 |       .getByRole('button', { name: /Deactivate/i });
  132 |     await deactivateBtn.click();
  133 |     await expect(page.locator('[data-sonner-toast]')).toContainText(
  134 |       /deactivated successfully/i,
  135 |     );
  136 |   });
  137 | 
  138 |   test('Staff Compliance Profile - Status Transitions', async ({ page }) => {
  139 |     // Navigate to a staff profile compliance tab
  140 |     // We'll search for 'Julian' to find a reliable record
  141 |     await page.goto('/staff');
  142 |     await page.getByPlaceholder(/Search staff/i).fill('Julian');
  143 |     await page.waitForTimeout(1000);
  144 |     const julianLink = page
  145 |       .locator('a[href*="/employees/staff-detail/"]')
  146 |       .first();
  147 |     await julianLink.click();
  148 | 
  149 |     await page
  150 |       .getByRole('link', { name: /Compliance/i })
  151 |       .or(page.locator('a:has-text("Compliance")'))
> 152 |       .click();
      |        ^ TimeoutError: locator.click: Timeout 30000ms exceeded.
  153 |     await expect(page.locator('#staff_compliance')).toBeVisible();
  154 | 
  155 |     // 1. Mark as In Progress
  156 |     const firstRow = page.locator('#staff_compliance table tbody tr').first();
  157 |     const inProgressBtn = firstRow.getByRole('button', {
  158 |       name: /In Progress/i,
  159 |     });
  160 |     await inProgressBtn.click();
  161 | 
  162 |     // Check if form fields appear (Doc #, Comments)
  163 |     await expect(firstRow.getByPlaceholder(/e.g. LIC123456/i)).toBeVisible();
  164 |     await firstRow.getByPlaceholder(/e.g. LIC123456/i).fill('E2E-TEST-123');
  165 | 
  166 |     // 2. Mark as Not Applicable
  167 |     const naBtn = firstRow.getByRole('button', { name: /N\/A/i });
  168 |     await naBtn.click();
  169 |     await expect(firstRow.getByText(/marked as Not Applicable/i)).toBeVisible();
  170 |     await firstRow
  171 |       .getByPlaceholder(/Enter any additional notes/i)
  172 |       .fill('Test N/A reason');
  173 | 
  174 |     // 3. Mark back to Complete (if applicable)
  175 |     const completeBtn = firstRow.getByRole('button', { name: /Complete/i });
  176 |     if (await completeBtn.isVisible()) {
  177 |       await completeBtn.click();
  178 |       await expect(firstRow.locator('.badge-success')).toBeVisible();
  179 |     }
  180 | 
  181 |     // 4. Global Save
  182 |     await page.getByRole('button', { name: /Save Changes/i }).click();
  183 |     await expect(page.locator('[data-sonner-toast]')).toContainText(
  184 |       /updated successfully/i,
  185 |     );
  186 |   });
  187 | 
  188 |   test('Compliance Monitoring Report - Gold Standard Layout', async ({
  189 |     page,
  190 |   }) => {
  191 |     await page.goto('/admin/reporting/compliance');
  192 | 
  193 |     // 1. Verify Sidebar Criteria
  194 |     await expect(page.getByText(/Report Criteria/i)).toBeVisible();
  195 |     await expect(page.getByText(/Filter by House/i)).toBeVisible();
  196 |     await expect(page.getByText(/Filter by Staff Member/i)).toBeVisible();
  197 | 
  198 |     // 2. Verify Printable Preview
  199 |     const reportPreview = page
  200 |       .locator('.print-container')
  201 |       .or(page.locator('.printable-report'));
  202 |     await expect(reportPreview).toBeVisible();
  203 |     await expect(reportPreview).toContainText(/Compliance Monitoring Report/i);
  204 | 
  205 |     // 3. Test Grouping Pivot
  206 |     await page
  207 |       .locator('label:has-text("Group Results By") + div [role="combobox"]')
  208 |       .click();
  209 |     await page.getByRole('option', { name: /Requirement/i }).click();
  210 |     await page.waitForLoadState('networkidle');
  211 | 
  212 |     // Verify grouping subheaders appear in the report
  213 |     const subheader = reportPreview.locator('h3').first();
  214 |     await expect(subheader).toBeVisible();
  215 | 
  216 |     // 4. Test "Actionable Only" toggle
  217 |     const actionableToggle = page.getByLabel(/Actionable Items Only/i);
  218 |     const isChecked = await actionableToggle.isChecked();
  219 |     await actionableToggle.click();
  220 |     await page.waitForLoadState('networkidle');
  221 |     // Ensure total items changed or loading indicator appeared
  222 |     await expect(page.locator('body')).not.toContainText(/White Screen/i);
  223 |   });
  224 | });
  225 | 
```