# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: e2e/crud-lifecycle.spec.ts >> Staff Lifecycle CRUD >> Complete Staff Record Lifecycle
- Location: tests/e2e/crud-lifecycle.spec.ts:13:3

# Error details

```
TimeoutError: locator.click: Timeout 15000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: /Add Staff/i })

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - region "Notifications alt+T"
  - generic [ref=e7]:
    - generic [ref=e8]:
      - img "InsideCare" [ref=e9]
      - heading "Sign In" [level=1] [ref=e10]
      - paragraph [ref=e11]: Welcome back! Log in with your credentials.
    - alert [ref=e12]:
      - img [ref=e14]
      - generic [ref=e16]: Development Environment - For testing only
    - generic [ref=e17]:
      - generic [ref=e18]: Email
      - textbox "Email" [ref=e19]:
        - /placeholder: Your email
    - generic [ref=e20]:
      - generic [ref=e22]: Password
      - generic [ref=e23]:
        - textbox "Password" [ref=e24]:
          - /placeholder: Your password
        - button [ref=e25] [cursor=pointer]:
          - img [ref=e26]
    - generic [ref=e30]:
      - generic [ref=e31]:
        - checkbox "Remember me" [checked] [ref=e32]:
          - generic:
            - img
        - checkbox [checked]
        - generic [ref=e33] [cursor=pointer]: Remember me
      - link "Forgot Password?" [ref=e34] [cursor=pointer]:
        - /url: /auth/reset-password
    - button "Sign In" [ref=e35] [cursor=pointer]
    - generic [ref=e36]:
      - paragraph [ref=e37]: Testing & Development
      - generic [ref=e38]:
        - button "Admin" [ref=e39] [cursor=pointer]
        - button "Support Worker" [ref=e40] [cursor=pointer]
        - button "Supervisor" [ref=e41] [cursor=pointer]
        - button "House Manager" [ref=e42] [cursor=pointer]
        - button "Director" [ref=e43] [cursor=pointer]
        - button "Finance Manager" [ref=e44] [cursor=pointer]
```

# Test source

```ts
  1   | import { test, expect } from '@playwright/test';
  2   | 
  3   | /**
  4   |  * COMPREHENSIVE CRUD INTEGRATION TESTS
  5   |  * 
  6   |  * These tests verify the full lifecycle of data entities (Create -> Read -> Update -> Delete).
  7   |  * They follow the app's "Create (Draft) -> Navigate to Detail -> Edit" flow.
  8   |  */
  9   | 
  10  | test.describe('Staff Lifecycle CRUD', () => {
  11  |   test.use({ storageState: 'playwright/.auth/admin.json' });
  12  | 
  13  |   test('Complete Staff Record Lifecycle', async ({ page }) => {
  14  |     test.slow();
  15  |     const timestamp = Date.now();
  16  |     const staffName = `Test Engineer ${timestamp}`;
  17  | 
  18  |     // 1. Create Staff
  19  |     await page.goto('/staff');
> 20  |     await page.getByRole('button', { name: /Add Staff/i }).click({ force: true });
      |                                                            ^ TimeoutError: locator.click: Timeout 15000ms exceeded.
  21  |     
  22  |     await expect(page).toHaveURL(/\/employees\/staff-detail\//, { timeout: 45000 });
  23  |     await expect(page.getByText(/Loading staff member/i)).not.toBeVisible({ timeout: 30000 });
  24  |     await expect(page.getByRole('heading', { name: /Staff Details/i }).or(page.getByText(/Staff Profile/i)).first()).toBeVisible({ timeout: 30000 });
  25  | 
  26  |     // 2. Update Basic Info
  27  |     await page.locator('input#staff_name').fill(staffName, { timeout: 30000 });
  28  |     const staffEmail = `test.staff.${timestamp}@insidecare.com.au`;
  29  |     await page.locator('input#email').fill(staffEmail);
  30  |     await page.locator('textarea#hobbies').fill('Automated Testing');
  31  | 
  32  |     // 3. Set Compliance
  33  |     await page.getByText(/Compliance/i).first().click({ force: true });
  34  |     const ndisCheck = page.locator('button#ndis_worker_screening_check').or(page.locator('input#ndis_worker_screening_check'));
  35  |     await expect(ndisCheck).toBeVisible({ timeout: 20000 });
  36  |     await ndisCheck.click({ force: true });
  37  |     
  38  |     // 4. Add Training
  39  |     await page.getByText(/Training/i).first().click({ force: true });
  40  |     const addTrainingBtn = page.getByRole('button', { name: /Add Training/i });
  41  |     await expect(addTrainingBtn).toBeVisible({ timeout: 20000 });
  42  |     await addTrainingBtn.click({ force: true });
  43  |     
  44  |     await page.locator('input#title').fill('Fire Safety');
  45  |     await page.locator('input#category').fill('Safety');
  46  |     await page.getByRole('button', { name: /Save/i }).click({ force: true });
  47  | 
  48  |     // 5. Final Save
  49  |     const saveButton = page.getByRole('button', { name: /Save Changes/i });
  50  |     await expect(saveButton).toBeEnabled({ timeout: 20000 });
  51  |     await saveButton.click({ force: true });
  52  |     await expect(page.locator('[data-sonner-toast]')).toContainText(/success|updated/i, { timeout: 30000 });
  53  | 
  54  |     // 6. Activation (Business Logic)
  55  |     await page.getByRole('button', { name: /Activate Staff/i }).click({ force: true });
  56  |     
  57  |     // Use dialog-specific locator to avoid ambiguity with toolbar buttons
  58  |     const activationDialog = page.getByRole('dialog');
  59  |     await expect(activationDialog).toBeVisible({ timeout: 10000 });
  60  |     await activationDialog.getByRole('button', { name: /Activate Only/i }).or(activationDialog.getByRole('button', { name: /Activate Staff/i })).click({ force: true });
  61  |     
  62  |     await expect(page.locator('[data-sonner-toast]')).toContainText(/activated/i, { timeout: 30000 });
  63  |     await expect(activationDialog).not.toBeVisible();
  64  | 
  65  |     // 7. Cleanup (Deactivate)
  66  |     await page.reload();
  67  |     await page.waitForLoadState('networkidle');
  68  |     await expect(page.locator('text=/Loading/i').first()).not.toBeVisible({ timeout: 30000 });
  69  |     
  70  |     const deactivateBtn = page.getByRole('button', { name: /Deactivate/i });
  71  |     await expect(deactivateBtn).toBeVisible({ timeout: 30000 });
  72  |     await deactivateBtn.scrollIntoViewIfNeeded();
  73  |     await deactivateBtn.click({ force: true });
  74  |     await page.getByRole('button', { name: /Deactivate Only/i }).or(page.getByRole('button', { name: /Deactivate Staff/i })).click({ force: true });
  75  |     await expect(page.locator('[data-sonner-toast]')).toContainText(/deactivated/i, { timeout: 30000 });
  76  |   });
  77  | });
  78  | 
  79  | test.describe('Participant Lifecycle CRUD', () => {
  80  |   test.use({ storageState: 'playwright/.auth/admin.json' });
  81  | 
  82  |   test('Complete Participant Record Lifecycle', async ({ page }) => {
  83  |     test.slow();
  84  |     const participantName = `Test Participant ${Date.now()}`;
  85  | 
  86  |     // 1. Create Participant
  87  |     await page.goto('/participants/profiles');
  88  |     await page.getByRole('button', { name: /Add Participant/i }).click({ force: true });
  89  |     
  90  |     await expect(page).toHaveURL(/\/participants\/detail\//, { timeout: 45000 });
  91  |     await expect(page.getByRole('heading', { name: /Participant Profile/i }).or(page.getByText(/Participant Profile/i)).first()).toBeVisible({ timeout: 30000 });
  92  | 
  93  |     // 2. Update Details
  94  |     await page.locator('input#participant_name').fill(participantName, { timeout: 30000 });
  95  |     await page.locator('input#ndis_number').fill('123456789');
  96  | 
  97  |     // 3. Add Goal
  98  |     await page.getByText(/Goals/i).first().click({ force: true });
  99  |     await expect(page.getByRole('button', { name: /Add Goal/i })).toBeEnabled({ timeout: 20000 });
  100 |     await page.getByRole('button', { name: /Add Goal/i }).click({ force: true });
  101 |     
  102 |     // Wait for Dialog to appear
  103 |     await expect(page.getByRole('dialog')).toBeVisible({ timeout: 10000 });
  104 |     await page.locator('textarea#description').fill('Learn Automated Testing');
  105 |     await page.getByRole('button', { name: /Save/i, exact: true }).click({ force: true });
  106 |     await expect(page.getByRole('dialog')).not.toBeVisible();
  107 | 
  108 |     // 4. Final Save
  109 |     const saveButton = page.getByRole('button', { name: /Save Changes/i });
  110 |     await expect(saveButton).toBeEnabled({ timeout: 20000 });
  111 |     await saveButton.click({ force: true });
  112 |     await expect(page.locator('[data-sonner-toast]')).toContainText(/success|saved/i, { timeout: 30000 });
  113 | 
  114 |     // 5. Cleanup (Archive)
  115 |     await page.goto('/participants/profiles');
  116 |     await page.getByPlaceholder(/Search Participants/i).fill(participantName);
  117 |     const row = page.locator('tr', { hasText: participantName });
  118 |     await expect(row.first()).toBeVisible({ timeout: 30000 });
  119 |     await row.first().getByRole('button', { name: /Archive/i }).click({ force: true });
  120 |     await expect(page.locator('[data-sonner-toast]')).toContainText(/archived/i, { timeout: 30000 });
```