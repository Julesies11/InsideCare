# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: e2e/participants-comprehensive.spec.ts >> Participant Management Comprehensive >> Navigate to participant detail and verify sections
- Location: tests/e2e/participants-comprehensive.spec.ts:30:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('table tbody tr').first()
Expected: visible
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 15000ms
  - waiting for locator('table tbody tr').first()

```

```yaml
- region "Notifications alt+T"
- img "InsideCare"
- heading "Sign In" [level=1]
- paragraph: Welcome back! Log in with your credentials.
- alert: Development Environment - For testing only
- text: Email
- textbox "Email":
  - /placeholder: Your email
- text: Password
- textbox "Password":
  - /placeholder: Your password
- button
- checkbox "Remember me" [checked]
- text: Remember me
- link "Forgot Password?":
  - /url: /auth/reset-password
- button "Sign In"
- paragraph: Testing & Development
- button "Admin"
- button "Support Worker"
- button "Supervisor"
- button "House Manager"
- button "Director"
- button "Finance Manager"
```

# Test source

```ts
  1   | import { test, expect } from '@playwright/test';
  2   | 
  3   | /**
  4   |  * Comprehensive tests for Participant Management.
  5   |  * Covers: Listing, Searching, Detailed View, Editing, Medications, and Documents.
  6   |  */
  7   | test.describe('Participant Management Comprehensive', () => {
  8   |   // Use admin session to ensure full access for all operations
  9   |   test.use({ storageState: 'playwright/.auth/admin.json' });
  10  | 
  11  |   test.beforeEach(async ({ page }) => {
  12  |     await page.goto('/participants/profiles');
  13  |     // Ensure loading is finished
  14  |     await expect(page.getByText(/Loading participants/i)).not.toBeVisible({ timeout: 30000 });
  15  |   });
  16  | 
  17  |   test('Search and filter participants', async ({ page }) => {
  18  |     const searchInput = page.getByPlaceholder(/Search Participants/i);
  19  |     await expect(searchInput).toBeVisible();
  20  | 
  21  |     // Search for a specific participant (assuming 'John' exists or just testing the filter logic)
  22  |     await searchInput.fill('John');
  23  |     await page.waitForTimeout(1000); // Wait for debounce/filtering
  24  | 
  25  |     // Verify results or empty state (no crash)
  26  |     const table = page.locator('table');
  27  |     await expect(table).toBeVisible();
  28  |   });
  29  | 
  30  |   test('Navigate to participant detail and verify sections', async ({ page }) => {
  31  |     // Click on the first "Edit" or "View" button
  32  |     const firstRow = page.locator('table tbody tr').first();
> 33  |     await expect(firstRow).toBeVisible({ timeout: 15000 });
      |                            ^ Error: expect(locator).toBeVisible() failed
  34  |     
  35  |     const viewButton = firstRow.getByRole('button', { name: /Edit/i }).or(firstRow.getByRole('button', { name: /View/i }));
  36  |     await viewButton.click();
  37  | 
  38  |     // Verify redirection to detail page
  39  |     await expect(page).toHaveURL(/\/participants\/detail\//);
  40  | 
  41  |     // Verify primary sections are present via Sidebar links
  42  |     await expect(page.getByText("Personal Details").first()).toBeVisible();
  43  |     await expect(page.getByText("Medications").first()).toBeVisible();
  44  |     await expect(page.getByText("Documents").first()).toBeVisible();
  45  |   });
  46  | 
  47  |   test('Edit participant basic info and verify dirty tracking', async ({ page }) => {
  48  |     const firstRow = page.locator('table tbody tr').first();
  49  |     await firstRow.getByRole('button', { name: /Edit/i }).click();
  50  | 
  51  |     // Modify a field (e.g., Full Name)
  52  |     const nameInput = page.locator('input#participant_name');
  53  |     await expect(nameInput).toBeVisible({ timeout: 15000 });
  54  |     
  55  |     const originalValue = await nameInput.inputValue();
  56  |     await nameInput.fill(`${originalValue} Updated`);
  57  | 
  58  |     // Verify "Save Changes" button becomes enabled (if it's tied to dirty tracking)
  59  |     const saveButton = page.getByRole('button', { name: /Save Changes/i });
  60  |     await expect(saveButton).toBeEnabled();
  61  | 
  62  |     // Attempt to navigate away and check for unsaved changes prompt
  63  |     const dialogPromise = page.waitForEvent('dialog');
  64  |     // Clicking the Back button on the toolbar triggers window.confirm
  65  |     const backBtn = page.getByRole('button', { name: /Back/i });
  66  |     await expect(backBtn).toBeVisible({ timeout: 15000 });
  67  |     await backBtn.click({ force: true });
  68  |     
  69  |     const dialog = await dialogPromise;
  70  |     expect(dialog.message().toLowerCase()).toContain('unsaved');
  71  |     await dialog.dismiss();
  72  |   });
  73  | 
  74  |   test('Manage Medications - Add Medication dialog', async ({ page }) => {
  75  |     const firstRow = page.locator('table tbody tr').first();
  76  |     await firstRow.getByRole('button', { name: /Edit/i }).click({ force: true });
  77  | 
  78  |     // Scroll to Medications section or use deep link
  79  |     await page.goto(`${page.url()}?tab=medications`);
  80  |     await expect(page.locator('#medications')).toBeVisible();
  81  | 
  82  |     // Click "Add Medication" button
  83  |     const addMedBtn = page.getByRole('button', { name: /Add Medication/i });
  84  |     await expect(addMedBtn).toBeVisible({ timeout: 20000 });
  85  |     await addMedBtn.scrollIntoViewIfNeeded();
  86  |     await addMedBtn.click({ force: true });
  87  | 
  88  |     // Verify dialog appears
  89  |     const dialog = page.locator('[role="dialog"]').or(page.locator('.fixed.inset-0')).first();
  90  |     await expect(dialog).toBeVisible({ timeout: 30000 });
  91  |     await expect(dialog.getByText(/Medication/i)).toBeVisible({ timeout: 15000 });
  92  | 
  93  |     // Close dialog
  94  |     await dialog.getByRole('button', { name: /Cancel/i }).or(dialog.locator('button[aria-label="Close"]')).click();
  95  |     await expect(dialog).not.toBeVisible();
  96  |   });
  97  | 
  98  |   test('Manage Documents - List and Action buttons', async ({ page }) => {
  99  |     const firstRow = page.locator('table tbody tr').first();
  100 |     await firstRow.getByRole('button', { name: /Edit/i }).click();
  101 | 
  102 |     await page.goto(`${page.url()}?tab=documents`);
  103 |     await expect(page.locator('#documents')).toBeVisible();
  104 | 
  105 |     // Verify "Upload Document" button
  106 |     const uploadBtn = page.getByRole('button', { name: /Upload Document/i });
  107 |     await expect(uploadBtn).toBeVisible();
  108 | 
  109 |     // Check if there are existing documents and verify their action buttons (Edit, Download, Delete)
  110 |     // This depends on seed data, so we just check for the table/list structure
  111 |     const docContainer = page.locator('#documents');
  112 |     await expect(docContainer).toBeVisible();
  113 |   });
  114 | });
  115 | 
```